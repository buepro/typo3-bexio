
-- Dump of TYPO3 Connection "Default"
-- MariaDB dump 10.19  Distrib 10.5.12-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: db    Database: db
-- ------------------------------------------------------
-- Server version	10.3.34-MariaDB-1:10.3.34+maria~focal-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `backend_layout`
--

DROP TABLE IF EXISTS `backend_layout`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `backend_layout` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(11) NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `cruser_id` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `sorting` int(11) NOT NULL DEFAULT 0,
  `description` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `t3_origuid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_oid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_wsid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_state` smallint(6) NOT NULL DEFAULT 0,
  `t3ver_stage` int(11) NOT NULL DEFAULT 0,
  `title` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `config` text COLLATE utf8_unicode_ci NOT NULL,
  `icon` text COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`,`hidden`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `backend_layout`
--

LOCK TABLES `backend_layout` WRITE;
/*!40000 ALTER TABLE `backend_layout` DISABLE KEYS */;
/*!40000 ALTER TABLE `backend_layout` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `be_dashboards`
--

DROP TABLE IF EXISTS `be_dashboards`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `be_dashboards` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `cruser_id` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `identifier` varchar(120) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `title` varchar(120) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `widgets` text COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`,`hidden`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `be_dashboards`
--

LOCK TABLES `be_dashboards` WRITE;
/*!40000 ALTER TABLE `be_dashboards` DISABLE KEYS */;
INSERT INTO `be_dashboards` VALUES (1,0,1652457393,1652457393,1,0,0,0,0,'e800cefd2448b794619ba2cc7653fe30287679e9','My dashboard','{\"e327d877fcf361064d7414bd3f45e40b77221d31\":{\"identifier\":\"t3information\"},\"cc5c2f46bf14506e48206087621a049150422d83\":{\"identifier\":\"docGettingStarted\"}}');
/*!40000 ALTER TABLE `be_dashboards` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `be_groups`
--

DROP TABLE IF EXISTS `be_groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `be_groups` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `cruser_id` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `description` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `title` varchar(50) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `non_exclude_fields` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `explicit_allowdeny` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `allowed_languages` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `custom_options` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `db_mountpoints` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `pagetypes_select` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `tables_select` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `tables_modify` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `groupMods` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `availableWidgets` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `mfa_providers` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `file_mountpoints` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `file_permissions` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `TSconfig` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `subgroup` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `workspace_perms` smallint(6) NOT NULL DEFAULT 1,
  `category_perms` longtext COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`,`hidden`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `be_groups`
--

LOCK TABLES `be_groups` WRITE;
/*!40000 ALTER TABLE `be_groups` DISABLE KEYS */;
/*!40000 ALTER TABLE `be_groups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `be_users`
--

DROP TABLE IF EXISTS `be_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `be_users` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `cruser_id` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `disable` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `description` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `username` varchar(50) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `avatar` int(10) unsigned NOT NULL DEFAULT 0,
  `password` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `admin` smallint(5) unsigned NOT NULL DEFAULT 0,
  `usergroup` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `lang` varchar(10) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'default',
  `email` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `db_mountpoints` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `options` smallint(5) unsigned NOT NULL DEFAULT 0,
  `realName` varchar(80) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `userMods` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `allowed_languages` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `uc` mediumblob DEFAULT NULL,
  `file_mountpoints` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `file_permissions` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `workspace_perms` smallint(6) NOT NULL DEFAULT 1,
  `TSconfig` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `lastlogin` int(10) unsigned NOT NULL DEFAULT 0,
  `workspace_id` int(11) NOT NULL DEFAULT 0,
  `mfa` mediumblob DEFAULT NULL,
  `category_perms` longtext COLLATE utf8_unicode_ci DEFAULT NULL,
  `password_reset_token` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`uid`),
  KEY `username` (`username`),
  KEY `parent` (`pid`,`deleted`,`disable`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `be_users`
--

LOCK TABLES `be_users` WRITE;
/*!40000 ALTER TABLE `be_users` DISABLE KEYS */;
INSERT INTO `be_users` VALUES (1,0,1652457431,1652457361,0,0,0,0,0,NULL,'admin',0,'$argon2i$v=19$m=65536,t=16,p=1$V2lteC9jY3k4NUc5a0ZNQw$OKdzi9uEEwpZ/FQtg8G5hj6V7cEWHdbTSqKmaN1PU+E',1,NULL,'default','',NULL,0,'',NULL,'','a:12:{s:14:\"interfaceSetup\";s:7:\"backend\";s:10:\"moduleData\";a:9:{s:28:\"dashboard/current_dashboard/\";s:40:\"e800cefd2448b794619ba2cc7653fe30287679e9\";s:8:\"web_list\";a:3:{s:8:\"function\";N;s:8:\"language\";N;s:19:\"constant_editor_cat\";N;}s:10:\"FormEngine\";a:2:{i:0;a:4:{s:32:\"51248867bb2e5ea1db3f82e07650b6b2\";a:4:{i:0;s:38:\"bexio-02e74f10e0327ad868d138f2b4fdd6f0\";i:1;a:5:{s:4:\"edit\";a:1:{s:8:\"fe_users\";a:1:{i:45;s:4:\"edit\";}}s:7:\"defVals\";N;s:12:\"overrideVals\";N;s:11:\"columnsOnly\";N;s:6:\"noView\";N;}i:2;s:32:\"&edit%5Bfe_users%5D%5B45%5D=edit\";i:3;a:5:{s:5:\"table\";s:8:\"fe_users\";s:3:\"uid\";i:45;s:3:\"pid\";i:2;s:3:\"cmd\";s:4:\"edit\";s:12:\"deleteAccess\";b:1;}}s:32:\"80bea86936cd52a9dbfacb48fe1e3c81\";a:4:{i:0;s:38:\"bexio-17e62166fc8586dfa4d1bc0e1742c08b\";i:1;a:5:{s:4:\"edit\";a:1:{s:8:\"fe_users\";a:1:{i:52;s:4:\"edit\";}}s:7:\"defVals\";N;s:12:\"overrideVals\";N;s:11:\"columnsOnly\";N;s:6:\"noView\";N;}i:2;s:32:\"&edit%5Bfe_users%5D%5B52%5D=edit\";i:3;a:5:{s:5:\"table\";s:8:\"fe_users\";s:3:\"uid\";i:52;s:3:\"pid\";i:2;s:3:\"cmd\";s:4:\"edit\";s:12:\"deleteAccess\";b:1;}}s:32:\"3c215b1f305eabd0a5ea92619361a747\";a:4:{i:0;s:38:\"bexio-02e74f10e0327ad868d138f2b4fdd6f0\";i:1;a:5:{s:4:\"edit\";a:1:{s:8:\"fe_users\";a:1:{i:19;s:4:\"edit\";}}s:7:\"defVals\";N;s:12:\"overrideVals\";N;s:11:\"columnsOnly\";N;s:6:\"noView\";N;}i:2;s:32:\"&edit%5Bfe_users%5D%5B19%5D=edit\";i:3;a:5:{s:5:\"table\";s:8:\"fe_users\";s:3:\"uid\";i:19;s:3:\"pid\";i:2;s:3:\"cmd\";s:4:\"edit\";s:12:\"deleteAccess\";b:1;}}s:32:\"7585d53d4c90722bd9f8d15e5e623338\";a:4:{i:0;s:42:\"cmd inv test, RE-00148, 90, 01-07-22 23:59\";i:1;a:5:{s:4:\"edit\";a:1:{s:29:\"tx_bexio_domain_model_invoice\";a:1:{i:20;s:4:\"edit\";}}s:7:\"defVals\";N;s:12:\"overrideVals\";N;s:11:\"columnsOnly\";N;s:6:\"noView\";N;}i:2;s:53:\"&edit%5Btx_bexio_domain_model_invoice%5D%5B20%5D=edit\";i:3;a:5:{s:5:\"table\";s:29:\"tx_bexio_domain_model_invoice\";s:3:\"uid\";i:20;s:3:\"pid\";i:3;s:3:\"cmd\";s:4:\"edit\";s:12:\"deleteAccess\";b:1;}}}i:1;s:32:\"7585d53d4c90722bd9f8d15e5e623338\";}s:57:\"TYPO3\\CMS\\Backend\\Utility\\BackendUtility::getUpdateSignal\";a:0:{}s:6:\"web_ts\";a:3:{s:8:\"function\";s:85:\"TYPO3\\CMS\\Tstemplate\\Controller\\TypoScriptTemplateInformationModuleFunctionController\";s:8:\"language\";N;s:19:\"constant_editor_cat\";s:14:\"frontend login\";}s:10:\"web_layout\";a:3:{s:8:\"function\";s:1:\"1\";s:8:\"language\";s:1:\"0\";s:19:\"constant_editor_cat\";N;}s:13:\"system_config\";a:3:{s:4:\"tree\";s:3:\"tca\";s:11:\"regexSearch\";b:0;s:8:\"node_tca\";a:16:{s:14:\"fe_users.types\";i:1;s:16:\"fe_users.types.0\";i:1;s:51:\"fe_users.types.Tx_Extbase_Domain_Model_FrontendUser\";i:1;s:28:\"fe_users.columns.name.config\";i:1;s:17:\"fe_users.palettes\";i:1;s:33:\"fe_users.palettes.timeRestriction\";i:1;s:23:\"fe_users.palettes.bexio\";i:1;s:28:\"fe_users.columns.tx_bexio_id\";i:1;s:22:\"fe_users.columns.title\";i:1;s:35:\"fe_users.columns.tx_bexio_id.config\";i:1;s:29:\"fe_users.columns.title.config\";i:1;s:19:\"fe_users.palettes.2\";i:1;s:29:\"tx_bexio_domain_model_invoice\";i:1;s:37:\"tx_bexio_domain_model_invoice.columns\";i:1;s:42:\"tx_bexio_domain_model_invoice.columns.user\";i:1;s:49:\"tx_bexio_domain_model_invoice.columns.user.config\";i:1;}}s:18:\"list/displayFields\";a:2:{s:8:\"fe_users\";a:7:{i:0;s:8:\"username\";i:1;s:7:\"company\";i:2;s:6:\"crdate\";i:3;s:10:\"first_name\";i:4;s:11:\"tx_bexio_id\";i:5;s:6:\"tstamp\";i:6;s:9:\"last_name\";}s:29:\"tx_bexio_domain_model_invoice\";a:4:{i:0;s:5:\"title\";i:1;s:2:\"id\";i:2;s:20:\"payment_process_time\";i:3;s:17:\"kb_item_status_id\";}}s:16:\"opendocs::recent\";a:6:{s:32:\"343a7506939133e3cc694872fed7f28d\";a:4:{i:0;s:38:\"bexio-02e74f10e0327ad868d138f2b4fdd6f0\";i:1;a:5:{s:4:\"edit\";a:1:{s:8:\"fe_users\";a:1:{i:26;s:4:\"edit\";}}s:7:\"defVals\";N;s:12:\"overrideVals\";N;s:11:\"columnsOnly\";N;s:6:\"noView\";N;}i:2;s:32:\"&edit%5Bfe_users%5D%5B26%5D=edit\";i:3;a:5:{s:5:\"table\";s:8:\"fe_users\";s:3:\"uid\";i:26;s:3:\"pid\";i:2;s:3:\"cmd\";s:4:\"edit\";s:12:\"deleteAccess\";b:1;}}s:32:\"80bea86936cd52a9dbfacb48fe1e3c81\";a:4:{i:0;s:38:\"bexio-17e62166fc8586dfa4d1bc0e1742c08b\";i:1;a:5:{s:4:\"edit\";a:1:{s:8:\"fe_users\";a:1:{i:52;s:4:\"edit\";}}s:7:\"defVals\";N;s:12:\"overrideVals\";N;s:11:\"columnsOnly\";N;s:6:\"noView\";N;}i:2;s:32:\"&edit%5Bfe_users%5D%5B52%5D=edit\";i:3;a:5:{s:5:\"table\";s:8:\"fe_users\";s:3:\"uid\";i:52;s:3:\"pid\";i:2;s:3:\"cmd\";s:4:\"edit\";s:12:\"deleteAccess\";b:1;}}s:32:\"15e56f0e8edda5b0a199b2e7ccf792a8\";a:4:{i:0;s:66:\"cmd inv, bexio-02e74f10e0327ad868d138f2b4fdd6f0, cmd inv, RE-00147\";i:1;a:5:{s:4:\"edit\";a:1:{s:29:\"tx_bexio_domain_model_invoice\";a:1:{i:19;s:4:\"edit\";}}s:7:\"defVals\";N;s:12:\"overrideVals\";N;s:11:\"columnsOnly\";N;s:6:\"noView\";N;}i:2;s:53:\"&edit%5Btx_bexio_domain_model_invoice%5D%5B19%5D=edit\";i:3;a:5:{s:5:\"table\";s:29:\"tx_bexio_domain_model_invoice\";s:3:\"uid\";i:19;s:3:\"pid\";i:1;s:3:\"cmd\";s:4:\"edit\";s:12:\"deleteAccess\";b:1;}}s:32:\"61bd2d4a32651448eecf4aa71f49da52\";a:4:{i:0;s:114:\"atemtherapie-interlaken.ch, bexio-c4ca4238a0b923820dcc509a6f75849b, atemtherapie-interlaken.ch, RE-00119, VO2lpm2P\";i:1;a:5:{s:4:\"edit\";a:1:{s:29:\"tx_bexio_domain_model_invoice\";a:1:{i:1;s:4:\"edit\";}}s:7:\"defVals\";N;s:12:\"overrideVals\";N;s:11:\"columnsOnly\";N;s:6:\"noView\";N;}i:2;s:52:\"&edit%5Btx_bexio_domain_model_invoice%5D%5B1%5D=edit\";i:3;a:5:{s:5:\"table\";s:29:\"tx_bexio_domain_model_invoice\";s:3:\"uid\";i:1;s:3:\"pid\";i:1;s:3:\"cmd\";s:4:\"edit\";s:12:\"deleteAccess\";b:1;}}s:32:\"3c215b1f305eabd0a5ea92619361a747\";a:4:{i:0;s:38:\"bexio-02e74f10e0327ad868d138f2b4fdd6f0\";i:1;a:5:{s:4:\"edit\";a:1:{s:8:\"fe_users\";a:1:{i:19;s:4:\"edit\";}}s:7:\"defVals\";N;s:12:\"overrideVals\";N;s:11:\"columnsOnly\";N;s:6:\"noView\";N;}i:2;s:32:\"&edit%5Bfe_users%5D%5B19%5D=edit\";i:3;a:5:{s:5:\"table\";s:8:\"fe_users\";s:3:\"uid\";i:19;s:3:\"pid\";i:2;s:3:\"cmd\";s:4:\"edit\";s:12:\"deleteAccess\";b:1;}}s:32:\"eed2902fe26944fd1a97520e84fe9de4\";a:4:{i:0;s:38:\"bexio-c20ad4d76fe97759aa27a0c99bff6710\";i:1;a:5:{s:4:\"edit\";a:1:{s:8:\"fe_users\";a:1:{i:10;s:4:\"edit\";}}s:7:\"defVals\";N;s:12:\"overrideVals\";N;s:11:\"columnsOnly\";N;s:6:\"noView\";N;}i:2;s:32:\"&edit%5Bfe_users%5D%5B10%5D=edit\";i:3;a:5:{s:5:\"table\";s:8:\"fe_users\";s:3:\"uid\";i:10;s:3:\"pid\";i:2;s:3:\"cmd\";s:4:\"edit\";s:12:\"deleteAccess\";b:1;}}}}s:14:\"emailMeAtLogin\";i:0;s:8:\"titleLen\";i:50;s:8:\"edit_RTE\";s:1:\"1\";s:20:\"edit_docModuleUpload\";s:1:\"1\";s:25:\"resizeTextareas_MaxHeight\";i:500;s:4:\"lang\";s:7:\"default\";s:19:\"firstLoginTimeStamp\";i:1652457389;s:15:\"moduleSessionID\";a:8:{s:28:\"dashboard/current_dashboard/\";s:40:\"28bbf69653c2b60f47a82e01e0da1e51a9912d95\";s:8:\"web_list\";s:40:\"28bbf69653c2b60f47a82e01e0da1e51a9912d95\";s:10:\"FormEngine\";s:40:\"f95dfee0318da5669ad92af5efbe207135cea7b1\";s:57:\"TYPO3\\CMS\\Backend\\Utility\\BackendUtility::getUpdateSignal\";s:40:\"f95dfee0318da5669ad92af5efbe207135cea7b1\";s:6:\"web_ts\";s:40:\"5aa98f37b3074d61deeb0a1d7b8a00863dad4991\";s:10:\"web_layout\";s:40:\"c223392d3271c278bb76c5bcba506157153fe866\";s:18:\"list/displayFields\";s:40:\"f95dfee0318da5669ad92af5efbe207135cea7b1\";s:16:\"opendocs::recent\";s:40:\"f95dfee0318da5669ad92af5efbe207135cea7b1\";}s:17:\"BackendComponents\";a:1:{s:6:\"States\";a:2:{s:8:\"Pagetree\";a:1:{s:9:\"stateHash\";a:2:{s:3:\"0_0\";s:1:\"1\";s:3:\"0_1\";s:1:\"1\";}}s:17:\"typo3-module-menu\";a:1:{s:9:\"collapsed\";s:4:\"true\";}}}s:10:\"inlineView\";s:270:\"{\"fe_users\":{\"19\":{\"tx_bexio_domain_model_invoice\":[]},\"26\":{\"tx_bexio_domain_model_invoice\":{\"1\":\"\"}},\"7\":{\"tx_bexio_domain_model_invoice\":{\"1\":\"\"}}},\"tx_bexio_domain_model_invoice\":{\"1\":{\"fe_users\":{\"5\":\"\"}},\"4\":{\"fe_users\":[\"4\"]},\"19\":{\"fe_users\":{\"0\":\"19\",\"2\":\"\"}}}}\";}',NULL,NULL,1,NULL,1654704782,0,NULL,NULL,'');
/*!40000 ALTER TABLE `be_users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fe_groups`
--

DROP TABLE IF EXISTS `fe_groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fe_groups` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `cruser_id` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `description` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `tx_extbase_type` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  `title` varchar(50) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `subgroup` tinytext COLLATE utf8_unicode_ci DEFAULT NULL,
  `TSconfig` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `felogin_redirectPid` tinytext COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`,`hidden`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fe_groups`
--

LOCK TABLES `fe_groups` WRITE;
/*!40000 ALTER TABLE `fe_groups` DISABLE KEYS */;
INSERT INTO `fe_groups` VALUES (1,2,1653463503,1653463503,1,0,0,'','0','customer','','','');
/*!40000 ALTER TABLE `fe_groups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fe_users`
--

DROP TABLE IF EXISTS `fe_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fe_users` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `cruser_id` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `disable` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `description` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `tx_extbase_type` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  `username` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `password` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `usergroup` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `name` varchar(160) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `first_name` varchar(50) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `middle_name` varchar(50) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `last_name` varchar(50) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `address` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `telephone` varchar(30) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `fax` varchar(30) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `email` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `uc` blob DEFAULT NULL,
  `title` varchar(40) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `zip` varchar(10) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `city` varchar(50) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `country` varchar(40) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `www` varchar(80) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `company` varchar(80) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `image` tinytext COLLATE utf8_unicode_ci DEFAULT NULL,
  `TSconfig` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `lastlogin` int(10) unsigned NOT NULL DEFAULT 0,
  `is_online` int(10) unsigned NOT NULL DEFAULT 0,
  `mfa` mediumblob DEFAULT NULL,
  `felogin_redirectPid` tinytext COLLATE utf8_unicode_ci DEFAULT NULL,
  `felogin_forgotHash` varchar(80) COLLATE utf8_unicode_ci DEFAULT '',
  `tx_bexio_id` int(10) unsigned NOT NULL DEFAULT 0,
  `tx_bexio_company_id` int(10) unsigned NOT NULL DEFAULT 0,
  `tx_bexio_invoices` int(10) unsigned NOT NULL DEFAULT 0,
  `tx_bexio_language_id` int(10) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`username`(100)),
  KEY `username` (`username`(100)),
  KEY `is_online` (`is_online`),
  KEY `felogin_forgotHash` (`felogin_forgotHash`)
) ENGINE=InnoDB AUTO_INCREMENT=27 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fe_users`
--

LOCK TABLES `fe_users` WRITE;
/*!40000 ALTER TABLE `fe_users` DISABLE KEYS */;
INSERT INTO `fe_users` VALUES (1,2,1654585133,1654585133,0,0,0,0,0,NULL,'0','bexio-c4ca4238a0b923820dcc509a6f75849b','EdxIb7iUsVSzrBW4LqK#','1','','','','','Alte Jonastrasse 24','+41 (0) 71 552 00 60','','support@bexio.com',NULL,'','8640','Rapperswil','Schweiz','https://www.bexio.com','bexio AG',NULL,NULL,0,0,NULL,NULL,'',1,0,0,0),(2,2,1654585133,1654585133,0,0,0,0,0,NULL,'0','bexio-d3d9446802a44259755d38e6d163e820','M3Yt9iuflTHnySqgZBp4','1','','','','','Inselistrasse 5a','','','muri74@windowslive.com',NULL,'','3510','Konolfingen','Schweiz','','Schachklub Münsingen',NULL,NULL,0,0,NULL,NULL,'',10,0,0,0),(3,2,1654585133,1654585133,0,0,0,0,0,NULL,'0','bexio-33e75ff09dd601bbe69f351039152189','#TwnRjyHLAxYV4t8F$!I','1','','Alexander','','Schlegel','Bernhard-Borst-Str. 1','+49 89 33019446','','alexander.schlegel@nezzgo.com',NULL,'','80637','München','Deutschland','nezzgo.com','',NULL,NULL,0,0,NULL,NULL,'',28,0,0,0),(4,2,1654585133,1654585133,0,0,0,0,0,NULL,'0','bexio-c16a5320fa475530d9583c34fd356ef5','islS5CErynFhgH83BWOe','1','','Dina','','Paratte','Postfach 117','076 435 48 00','','info@dparatte.ch',NULL,'','8309','Nürensdorf','Schweiz','','',NULL,NULL,0,0,NULL,NULL,'',31,0,0,0),(5,2,1654585133,1654585133,0,0,0,0,0,NULL,'0','bexio-3416a75f4cea9109507cacd8e2f2aefc','HDYKJ8#N6dnqv9b2UMWw','1','','Hans-Georg','','Richter','Falkenstrasse 2','+49 8636 6090002','','hans-georg.richter@hard-info-soft.de',NULL,'','84539','Ampfing','Deutschland','','',NULL,NULL,0,0,NULL,NULL,'',41,0,0,0),(6,2,1654585133,1654585133,0,0,0,0,0,NULL,'0','bexio-eccbc87e4b5ce2fe28308fd9f2a7baf3','FPiQjlwq$0g4EZczMfk!','1','','Michael','','Zotter','Hansmatt 32','078 720 00 60','','michael@zottermedia.ch',NULL,'','6371','Stans','Schweiz','','zottermedia gmbh',NULL,NULL,0,0,NULL,NULL,'',3,2,0,1),(7,2,1654585133,1654585133,0,0,0,0,0,NULL,'0','bexio-e4da3b7fbbce2345d7772b0674a318d5','$ZOlFoJy3C1Y6fETt9xS','1','','Christoph','','Dietrich','Seestrasse 11','033 655 00 00','','info@memoweb.ch',NULL,'','3700','Spiez','Schweiz','https://www.popnet.ch','PopNet Informatik AG',NULL,NULL,0,0,NULL,NULL,'',5,4,0,0),(8,2,1654585133,1654585133,0,0,0,0,0,NULL,'0','bexio-8f14e45fceea167a5a36dedd4bea2543','ZKHQ$F3exoRL5ahvYX7O','1','','Ilpo','','Suominen','Kuokkamaantie 4 A','+358 50 365 2288','','ilpo.suominen@cavitar.com',NULL,'','33800','Tampere','Finnland','cavitar.com','Cavitar Ltd',NULL,NULL,0,0,NULL,NULL,'',7,6,0,4),(9,2,1654585133,1654585133,0,0,0,0,0,NULL,'0','bexio-45c48cce2e2d7fbdea1afc51c7c6ad26','0@at9rx6EBp#$Zh8IOJY','1','','Veronika','','Schöni','Widigasse 10','033 671 03 10','','vroni@schoeni-informatik.ch',NULL,'','3714','Frutigen','Schweiz','http://www.schoeni-informatik.ch/','Schöni Informatik',NULL,NULL,0,0,NULL,NULL,'',9,8,0,0),(10,2,1654585133,1654585133,0,0,0,0,0,NULL,'0','bexio-c20ad4d76fe97759aa27a0c99bff6710','1IbDmZT5HazrJO$N6!pn','1','','Spencer J.','','Ellis','Bernastrasse 25','+41 33 822 63 84','','sje@hotelforsale.ch',NULL,'','3800','Interlaken','Schweiz','hotelforsale.ch','zumkehr hotelforsale ag',NULL,NULL,0,0,NULL,NULL,'',12,11,0,0),(11,2,1654585133,1654585133,0,0,0,0,0,NULL,'0','bexio-aab3238922bcc25a6f606eb525ffdc56','sX@RWlIb2r51u$#FJiej','1','','Gabriela','','Jones','Erlenauweg 17\r\nGebäude \"Erlenaupark\"','+41 31 720 33 03','','gabriela.jones@belpmoos-reisen.ch',NULL,'','3110','Münsingen','Schweiz','www.belpmoos-reisen.ch','Belpmoos Reisen AG',NULL,NULL,0,0,NULL,NULL,'',14,13,0,0),(12,2,1654585133,1654585133,0,0,0,0,0,NULL,'0','bexio-c74d97b01eae257e44aa9d5bade97baf','0icwAO#eqUzP@YWFlnbh','1','','Niveetha','','Nadarajah','Bahnhofstrasse 4','','','direktion@krebshotel.ch',NULL,'','3800','Interlaken','Schweiz','','Hotel Krebs Interlaken',NULL,NULL,0,0,NULL,NULL,'',16,15,0,0),(13,2,1654585133,1654585133,0,0,0,0,0,NULL,'0','bexio-6f4922f45568161a8cdf4ad2299f6d23','!w2ZDEt6kdgIPzHVfoO@','1','','Eduardo','','Zenzen','Estrada João de Oliveira Remião, 777','+ 55 51 3220 9801','','eduardo.zenzen@ceitec-sa.com',NULL,'','91550-000','Porto Alegre','Brasilien','','CEITEC S.A - Semiconductors',NULL,NULL,0,0,NULL,NULL,'',18,17,0,4),(14,2,1654585133,1654585133,0,0,0,0,0,NULL,'0','bexio-98f13708210194c475687be6106a3b84','@ONqR1EbWVQTrKwLljsB','1','','Harri','','Hyppönen','Myllynkivenkuja 6','','','harri.hypponen@murata.com',NULL,'','01620','Vantaa','Finnland','','Murata Electronics Oy',NULL,NULL,0,0,NULL,NULL,'',20,19,0,4),(15,2,1654585133,1654585133,0,0,0,0,0,NULL,'0','bexio-b6d767d2f8ed5d21a44b0e5886680cb9','@938ydgFIE2Cjrw5Pebt','1','','Adrian','','Stalder','Grubenstrasse 9','','','adrian.stalder@microdul.com',NULL,'','8045','Zürich','Schweiz','','Microdul AG',NULL,NULL,0,0,NULL,NULL,'',22,21,0,0),(16,2,1654585133,1654585133,0,0,0,0,0,NULL,'0','bexio-37693cfc748049e45d87b8c7d8b9aacd','a26LTzDZ!hOkAP#H@s$u','1','','Aleksandar','','Mihajlov','Grubenstrasse 9','','','aleksandar.mihajlov@microdul.com',NULL,'','8045','Zürich','Schweiz','','Microdul AG',NULL,NULL,0,0,NULL,NULL,'',23,21,0,0),(17,2,1654585133,1654585133,0,0,0,0,0,NULL,'0','bexio-1ff1de774005f8da13f42943881c655f','pbRVq9Ninsha1S5lFwkU','1','','','','Microdul Rechnung','Grubenstrasse 9','','','rechnung@microdul.com',NULL,'','8045','Zürich','Schweiz','','Microdul AG',NULL,NULL,0,0,NULL,NULL,'',24,21,0,0),(18,2,1654585133,1654585133,0,0,0,0,0,NULL,'0','bexio-8e296a067a37563370ded05f5a3bf3ec','h5kHZaC7gw0!N1tbQMvz','1','','Thomas','','Strebel','Bernastrasse 25','+41 33 822 63 84','','ts@hotelforsale.ch',NULL,'','3800','Interlaken','Schweiz','hotelforsale.ch','zumkehr hotelforsale ag',NULL,NULL,0,0,NULL,NULL,'',25,11,0,0),(19,2,1654585133,1654585133,0,0,0,0,0,NULL,'0','bexio-02e74f10e0327ad868d138f2b4fdd6f0','9AlH!ieS#8gOuFLQko1Y','1','','Sonja','','Imobersteg','Schwandistrasse 12B','','','info@imobersteg-krantechnik.ch',NULL,'','3714','Frutigen','Schweiz','','Imobersteg GmbH',NULL,NULL,0,0,NULL,NULL,'',27,26,0,0),(20,2,1654585133,1654585133,0,0,0,0,0,NULL,'0','bexio-34173cb38f07f89ddbebc2ac9128303f','z$9xaO!Ybr0jGyLC#FiA','1','','','','Hofbauer','Jungfraustrasse 2','0338260350','','mail@weisseskreuz.ch',NULL,'','3800','Interlaken','Schweiz','weisseskreuz.ch','Hotel Weisses Kreuz AG',NULL,NULL,0,0,NULL,NULL,'',30,29,0,0),(21,2,1654585133,1654585133,0,0,0,0,0,NULL,'0','bexio-6364d3f0f495b6ab9dcf8d3b5c6e0b01','uGisSrl1vgbB8Z3h@pJx','1','','Dina','','Wyss','Erlenauweg 17\r\nGebäude \"Erlenaupark\"','079 285 12 16','','dina.wyss@spychergroup.ch',NULL,'','3110','Münsingen','Schweiz','www.belpmoos-reisen.ch','Belpmoos Reisen AG',NULL,NULL,0,0,NULL,NULL,'',32,13,0,0),(22,2,1654585133,1654585133,0,0,0,0,0,NULL,'0','bexio-e369853df766fa44e1ed0ff613f563bd','aNJ3gCLXkcIRqt$pPOu7','1','','Michael','','Deforné','Lausannegasse 60','+41 26 3225100','','michael@audiopur.ch',NULL,'','1700','Freiburg','Schweiz','','audiopur GmbH',NULL,NULL,0,0,NULL,NULL,'',34,33,0,0),(23,2,1654585133,1654585133,0,0,0,0,0,NULL,'0','bexio-19ca14e7ea6328a42e0eb13d585e4c22','jwSLanO5Qv0NkG8o7bWd','1','','Robert','','Lienert','Stampfenbachstrasse 57','+41 (0)44 500 27 02','','it@sac-uto.ch',NULL,'','8006','Zürich','Schweiz','https://www.sac-uto.ch','SAC Sektion Uto',NULL,NULL,0,0,NULL,NULL,'',36,35,0,0),(24,2,1654585133,1654585133,0,0,0,0,0,NULL,'0','bexio-a5771bce93e200c36f7cd9dfd0e5deaa','emIJa#WlwZUTuhxM!37X','1','','Peter Maria','','Engeli','Rotbergerstrasse 18','+41 61 283 10 73','','peter.maria.engeli@engeli.ch',NULL,'','4054','Basel','Schweiz','','ENGELI informa AG',NULL,NULL,0,0,NULL,NULL,'',38,37,0,0),(25,2,1654585133,1654585133,0,0,0,0,0,NULL,'0','bexio-d645920e395fedad7bbbed0eca3fe2e0','JzvkxPAdBNnH3@SWfiVg','1','','Lienert','','Robert','Postfach','044 500 27 02','','web@lienert.ch',NULL,'','8053','Zürich','Schweiz','','Lienert.ch AG',NULL,NULL,0,0,NULL,NULL,'',40,39,0,0),(26,2,1654585133,1654585133,0,0,0,0,0,NULL,'0','bexio-17e62166fc8586dfa4d1bc0e1742c08b','KnMs3JuXVRAH785tI4Dc','1','','Testvorname','','Testnachname','Teststrasse 1','','','romanb@ik.me',NULL,'','1111','Testwil','Schweiz','','Test GmbH',NULL,NULL,0,0,NULL,NULL,'',43,42,0,0);
/*!40000 ALTER TABLE `fe_users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pages`
--

DROP TABLE IF EXISTS `pages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pages` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(11) NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `cruser_id` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `fe_group` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  `sorting` int(11) NOT NULL DEFAULT 0,
  `rowDescription` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `editlock` smallint(5) unsigned NOT NULL DEFAULT 0,
  `sys_language_uid` int(11) NOT NULL DEFAULT 0,
  `l10n_parent` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_source` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_state` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `t3_origuid` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_diffsource` mediumblob DEFAULT NULL,
  `t3ver_oid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_wsid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_state` smallint(6) NOT NULL DEFAULT 0,
  `t3ver_stage` int(11) NOT NULL DEFAULT 0,
  `perms_userid` int(10) unsigned NOT NULL DEFAULT 0,
  `perms_groupid` int(10) unsigned NOT NULL DEFAULT 0,
  `perms_user` smallint(5) unsigned NOT NULL DEFAULT 0,
  `perms_group` smallint(5) unsigned NOT NULL DEFAULT 0,
  `perms_everybody` smallint(5) unsigned NOT NULL DEFAULT 0,
  `title` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `slug` varchar(2048) COLLATE utf8_unicode_ci DEFAULT NULL,
  `doktype` int(10) unsigned NOT NULL DEFAULT 0,
  `TSconfig` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `is_siteroot` smallint(6) NOT NULL DEFAULT 0,
  `php_tree_stop` smallint(6) NOT NULL DEFAULT 0,
  `url` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `shortcut` int(10) unsigned NOT NULL DEFAULT 0,
  `shortcut_mode` int(10) unsigned NOT NULL DEFAULT 0,
  `subtitle` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `layout` int(10) unsigned NOT NULL DEFAULT 0,
  `target` varchar(80) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `media` int(10) unsigned NOT NULL DEFAULT 0,
  `lastUpdated` int(10) unsigned NOT NULL DEFAULT 0,
  `keywords` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `cache_timeout` int(10) unsigned NOT NULL DEFAULT 0,
  `cache_tags` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `newUntil` int(10) unsigned NOT NULL DEFAULT 0,
  `description` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `no_search` smallint(5) unsigned NOT NULL DEFAULT 0,
  `SYS_LASTCHANGED` int(10) unsigned NOT NULL DEFAULT 0,
  `abstract` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `module` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `extendToSubpages` smallint(5) unsigned NOT NULL DEFAULT 0,
  `author` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `author_email` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `nav_title` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `nav_hide` smallint(6) NOT NULL DEFAULT 0,
  `content_from_pid` int(10) unsigned NOT NULL DEFAULT 0,
  `mount_pid` int(10) unsigned NOT NULL DEFAULT 0,
  `mount_pid_ol` smallint(6) NOT NULL DEFAULT 0,
  `l18n_cfg` smallint(6) NOT NULL DEFAULT 0,
  `fe_login_mode` smallint(6) NOT NULL DEFAULT 0,
  `backend_layout` varchar(64) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `backend_layout_next_level` varchar(64) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `tsconfig_includes` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `categories` int(10) unsigned NOT NULL DEFAULT 0,
  `tx_impexp_origuid` int(11) NOT NULL DEFAULT 0,
  `seo_title` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `no_index` smallint(6) NOT NULL DEFAULT 0,
  `no_follow` smallint(6) NOT NULL DEFAULT 0,
  `og_title` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `og_description` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `og_image` int(10) unsigned NOT NULL DEFAULT 0,
  `twitter_title` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `twitter_description` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `twitter_image` int(10) unsigned NOT NULL DEFAULT 0,
  `twitter_card` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `canonical_link` varchar(2048) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `sitemap_priority` decimal(2,1) NOT NULL DEFAULT 0.5,
  `sitemap_changefreq` varchar(10) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`uid`),
  KEY `determineSiteRoot` (`is_siteroot`),
  KEY `language_identifier` (`l10n_parent`,`sys_language_uid`),
  KEY `slug` (`slug`(127)),
  KEY `parent` (`pid`,`deleted`,`hidden`),
  KEY `translation_source` (`l10n_source`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pages`
--

LOCK TABLES `pages` WRITE;
/*!40000 ALTER TABLE `pages` DISABLE KEYS */;
INSERT INTO `pages` VALUES (1,0,1652457490,1652457445,1,0,0,0,0,'',256,NULL,0,0,0,0,NULL,0,'{\"doktype\":\"\",\"title\":\"\",\"slug\":\"\",\"nav_title\":\"\",\"subtitle\":\"\",\"seo_title\":\"\",\"description\":\"\",\"no_index\":\"\",\"no_follow\":\"\",\"canonical_link\":\"\",\"sitemap_changefreq\":\"\",\"sitemap_priority\":\"\",\"og_title\":\"\",\"og_description\":\"\",\"og_image\":\"\",\"twitter_title\":\"\",\"twitter_description\":\"\",\"twitter_image\":\"\",\"twitter_card\":\"\",\"abstract\":\"\",\"keywords\":\"\",\"author\":\"\",\"author_email\":\"\",\"lastUpdated\":\"\",\"layout\":\"\",\"newUntil\":\"\",\"backend_layout\":\"\",\"backend_layout_next_level\":\"\",\"content_from_pid\":\"\",\"target\":\"\",\"cache_timeout\":\"\",\"cache_tags\":\"\",\"is_siteroot\":\"\",\"no_search\":\"\",\"php_tree_stop\":\"\",\"module\":\"\",\"media\":\"\",\"tsconfig_includes\":\"\",\"TSconfig\":\"\",\"l18n_cfg\":\"\",\"hidden\":\"\",\"nav_hide\":\"\",\"starttime\":\"\",\"endtime\":\"\",\"extendToSubpages\":\"\",\"fe_group\":\"\",\"fe_login_mode\":\"\",\"editlock\":\"\",\"categories\":\"\",\"rowDescription\":\"\"}',0,0,0,0,1,0,31,27,0,'Home','/',1,NULL,1,0,'',0,0,'',0,'',0,0,NULL,0,'',0,NULL,0,1652457490,NULL,'',0,'','','',0,0,0,0,0,0,'','',NULL,0,0,'',0,0,'',NULL,0,'',NULL,0,'summary','',0.5,''),(2,1,1653463483,1653463479,1,0,0,0,0,'0',256,NULL,0,0,0,0,NULL,0,'{\"hidden\":\"\"}',0,0,0,0,1,0,31,27,0,'Users','/users',254,NULL,0,0,'',0,0,'',0,'',0,0,NULL,0,'',0,NULL,0,0,NULL,'',0,'','','',0,0,0,0,0,0,'','',NULL,0,0,'',0,0,'',NULL,0,'',NULL,0,'summary','',0.5,''),(3,1,1653994498,1653994493,1,0,0,0,0,'0',512,NULL,0,0,0,0,NULL,0,'{\"hidden\":\"\"}',0,0,0,0,1,0,31,27,0,'Invoices','/invoices',254,NULL,0,0,'',0,0,'',0,'',0,0,NULL,0,'',0,NULL,0,0,NULL,'',0,'','','',0,0,0,0,0,0,'','',NULL,0,0,'',0,0,'',NULL,0,'',NULL,0,'summary','',0.5,'');
/*!40000 ALTER TABLE `pages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_be_shortcuts`
--

DROP TABLE IF EXISTS `sys_be_shortcuts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_be_shortcuts` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `userid` int(10) unsigned NOT NULL DEFAULT 0,
  `route` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `arguments` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `description` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `sorting` int(11) NOT NULL DEFAULT 0,
  `sc_group` smallint(6) NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `event` (`userid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_be_shortcuts`
--

LOCK TABLES `sys_be_shortcuts` WRITE;
/*!40000 ALTER TABLE `sys_be_shortcuts` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_be_shortcuts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_category`
--

DROP TABLE IF EXISTS `sys_category`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_category` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(11) NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `cruser_id` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `sorting` int(11) NOT NULL DEFAULT 0,
  `description` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `sys_language_uid` int(11) NOT NULL DEFAULT 0,
  `l10n_parent` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_state` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `t3_origuid` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_diffsource` mediumblob DEFAULT NULL,
  `t3ver_oid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_wsid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_state` smallint(6) NOT NULL DEFAULT 0,
  `t3ver_stage` int(11) NOT NULL DEFAULT 0,
  `title` tinytext COLLATE utf8_unicode_ci NOT NULL,
  `items` int(11) NOT NULL DEFAULT 0,
  `parent` int(10) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `category_parent` (`parent`),
  KEY `category_list` (`pid`,`deleted`,`sys_language_uid`),
  KEY `parent` (`pid`,`deleted`,`hidden`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_category`
--

LOCK TABLES `sys_category` WRITE;
/*!40000 ALTER TABLE `sys_category` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_category` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_category_record_mm`
--

DROP TABLE IF EXISTS `sys_category_record_mm`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_category_record_mm` (
  `uid_local` int(10) unsigned NOT NULL DEFAULT 0,
  `uid_foreign` int(10) unsigned NOT NULL DEFAULT 0,
  `sorting` int(10) unsigned NOT NULL DEFAULT 0,
  `sorting_foreign` int(10) unsigned NOT NULL DEFAULT 0,
  `tablenames` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `fieldname` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  KEY `uid_local` (`uid_local`),
  KEY `uid_foreign` (`uid_foreign`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_category_record_mm`
--

LOCK TABLES `sys_category_record_mm` WRITE;
/*!40000 ALTER TABLE `sys_category_record_mm` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_category_record_mm` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_file`
--

DROP TABLE IF EXISTS `sys_file`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_file` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `last_indexed` int(11) NOT NULL DEFAULT 0,
  `missing` smallint(6) NOT NULL DEFAULT 0,
  `storage` int(11) NOT NULL DEFAULT 0,
  `type` varchar(10) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `metadata` int(11) NOT NULL DEFAULT 0,
  `identifier` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `identifier_hash` varchar(40) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `folder_hash` varchar(40) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `extension` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `mime_type` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `name` tinytext COLLATE utf8_unicode_ci DEFAULT NULL,
  `sha1` varchar(40) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `size` bigint(20) unsigned NOT NULL DEFAULT 0,
  `creation_date` int(11) NOT NULL DEFAULT 0,
  `modification_date` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `sel01` (`storage`,`identifier_hash`),
  KEY `folder` (`storage`,`folder_hash`),
  KEY `tstamp` (`tstamp`),
  KEY `lastindex` (`last_indexed`),
  KEY `sha1` (`sha1`),
  KEY `parent` (`pid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_file`
--

LOCK TABLES `sys_file` WRITE;
/*!40000 ALTER TABLE `sys_file` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_file` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_file_collection`
--

DROP TABLE IF EXISTS `sys_file_collection`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_file_collection` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(11) NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `cruser_id` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `description` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `sys_language_uid` int(11) NOT NULL DEFAULT 0,
  `l10n_parent` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_state` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `t3_origuid` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_diffsource` mediumblob DEFAULT NULL,
  `t3ver_oid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_wsid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_state` smallint(6) NOT NULL DEFAULT 0,
  `t3ver_stage` int(11) NOT NULL DEFAULT 0,
  `title` tinytext COLLATE utf8_unicode_ci DEFAULT NULL,
  `type` varchar(30) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'static',
  `files` int(11) NOT NULL DEFAULT 0,
  `storage` int(11) NOT NULL DEFAULT 0,
  `folder` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `recursive` smallint(6) NOT NULL DEFAULT 0,
  `category` int(10) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`,`hidden`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_file_collection`
--

LOCK TABLES `sys_file_collection` WRITE;
/*!40000 ALTER TABLE `sys_file_collection` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_file_collection` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_file_metadata`
--

DROP TABLE IF EXISTS `sys_file_metadata`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_file_metadata` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(11) NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `cruser_id` int(10) unsigned NOT NULL DEFAULT 0,
  `sys_language_uid` int(11) NOT NULL DEFAULT 0,
  `l10n_parent` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_state` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `t3_origuid` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_diffsource` mediumblob DEFAULT NULL,
  `t3ver_oid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_wsid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_state` smallint(6) NOT NULL DEFAULT 0,
  `t3ver_stage` int(11) NOT NULL DEFAULT 0,
  `file` int(11) NOT NULL DEFAULT 0,
  `title` tinytext COLLATE utf8_unicode_ci DEFAULT NULL,
  `width` int(11) NOT NULL DEFAULT 0,
  `height` int(11) NOT NULL DEFAULT 0,
  `description` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `alternative` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `categories` int(10) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `file` (`file`),
  KEY `fal_filelist` (`l10n_parent`,`sys_language_uid`),
  KEY `parent` (`pid`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_file_metadata`
--

LOCK TABLES `sys_file_metadata` WRITE;
/*!40000 ALTER TABLE `sys_file_metadata` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_file_metadata` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_file_processedfile`
--

DROP TABLE IF EXISTS `sys_file_processedfile`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_file_processedfile` (
  `uid` int(11) NOT NULL AUTO_INCREMENT,
  `tstamp` int(11) NOT NULL DEFAULT 0,
  `crdate` int(11) NOT NULL DEFAULT 0,
  `storage` int(11) NOT NULL DEFAULT 0,
  `original` int(11) NOT NULL DEFAULT 0,
  `identifier` varchar(512) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `name` tinytext COLLATE utf8_unicode_ci DEFAULT NULL,
  `processing_url` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `configuration` blob DEFAULT NULL,
  `configurationsha1` varchar(40) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `originalfilesha1` varchar(40) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `task_type` varchar(200) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `checksum` varchar(32) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `width` int(11) DEFAULT 0,
  `height` int(11) DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `combined_1` (`original`,`task_type`(100),`configurationsha1`),
  KEY `identifier` (`storage`,`identifier`(180))
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_file_processedfile`
--

LOCK TABLES `sys_file_processedfile` WRITE;
/*!40000 ALTER TABLE `sys_file_processedfile` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_file_processedfile` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_file_reference`
--

DROP TABLE IF EXISTS `sys_file_reference`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_file_reference` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(11) NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `cruser_id` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `sys_language_uid` int(11) NOT NULL DEFAULT 0,
  `l10n_parent` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_state` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `l10n_diffsource` mediumblob DEFAULT NULL,
  `t3ver_oid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_wsid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_state` smallint(6) NOT NULL DEFAULT 0,
  `t3ver_stage` int(11) NOT NULL DEFAULT 0,
  `uid_local` int(11) NOT NULL DEFAULT 0,
  `uid_foreign` int(11) NOT NULL DEFAULT 0,
  `tablenames` varchar(64) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `fieldname` varchar(64) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `sorting_foreign` int(11) NOT NULL DEFAULT 0,
  `table_local` varchar(64) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `title` tinytext COLLATE utf8_unicode_ci DEFAULT NULL,
  `description` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `alternative` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `link` varchar(1024) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `crop` varchar(4000) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `autoplay` smallint(6) NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `tablenames_fieldname` (`tablenames`(32),`fieldname`(12)),
  KEY `deleted` (`deleted`),
  KEY `uid_local` (`uid_local`),
  KEY `uid_foreign` (`uid_foreign`),
  KEY `combined_1` (`l10n_parent`,`t3ver_oid`,`t3ver_wsid`,`t3ver_state`,`deleted`),
  KEY `parent` (`pid`,`deleted`,`hidden`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_file_reference`
--

LOCK TABLES `sys_file_reference` WRITE;
/*!40000 ALTER TABLE `sys_file_reference` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_file_reference` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_file_storage`
--

DROP TABLE IF EXISTS `sys_file_storage`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_file_storage` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `cruser_id` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `description` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `driver` tinytext COLLATE utf8_unicode_ci DEFAULT NULL,
  `configuration` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `is_default` smallint(6) NOT NULL DEFAULT 0,
  `is_browsable` smallint(6) NOT NULL DEFAULT 0,
  `is_public` smallint(6) NOT NULL DEFAULT 0,
  `is_writable` smallint(6) NOT NULL DEFAULT 0,
  `is_online` smallint(6) NOT NULL DEFAULT 1,
  `auto_extract_metadata` smallint(6) NOT NULL DEFAULT 1,
  `processingfolder` tinytext COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_file_storage`
--

LOCK TABLES `sys_file_storage` WRITE;
/*!40000 ALTER TABLE `sys_file_storage` DISABLE KEYS */;
INSERT INTO `sys_file_storage` VALUES (1,0,1652457411,1652457411,0,0,'This is the local fileadmin/ directory. This storage mount has been created automatically by TYPO3.','fileadmin','Local','<?xml version=\"1.0\" encoding=\"utf-8\" standalone=\"yes\" ?>\n<T3FlexForms>\n    <data>\n        <sheet index=\"sDEF\">\n            <language index=\"lDEF\">\n                <field index=\"basePath\">\n                    <value index=\"vDEF\">fileadmin/</value>\n                </field>\n                <field index=\"pathType\">\n                    <value index=\"vDEF\">relative</value>\n                </field>\n                <field index=\"caseSensitive\">\n                    <value index=\"vDEF\">1</value>\n                </field>\n            </language>\n        </sheet>\n    </data>\n</T3FlexForms>',1,1,1,1,1,1,NULL);
/*!40000 ALTER TABLE `sys_file_storage` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_filemounts`
--

DROP TABLE IF EXISTS `sys_filemounts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_filemounts` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `sorting` int(11) NOT NULL DEFAULT 0,
  `description` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `title` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `path` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `base` int(10) unsigned NOT NULL DEFAULT 0,
  `read_only` smallint(5) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`,`hidden`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_filemounts`
--

LOCK TABLES `sys_filemounts` WRITE;
/*!40000 ALTER TABLE `sys_filemounts` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_filemounts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_history`
--

DROP TABLE IF EXISTS `sys_history`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_history` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `actiontype` smallint(6) NOT NULL DEFAULT 0,
  `usertype` varchar(2) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'BE',
  `userid` int(10) unsigned DEFAULT NULL,
  `originaluserid` int(10) unsigned DEFAULT NULL,
  `recuid` int(11) NOT NULL DEFAULT 0,
  `tablename` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `history_data` mediumtext COLLATE utf8_unicode_ci DEFAULT NULL,
  `workspace` int(11) DEFAULT 0,
  `correlation_id` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`uid`),
  KEY `recordident_1` (`tablename`(100),`recuid`),
  KEY `recordident_2` (`tablename`(100),`tstamp`)
) ENGINE=InnoDB AUTO_INCREMENT=48 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_history`
--

LOCK TABLES `sys_history` WRITE;
/*!40000 ALTER TABLE `sys_history` DISABLE KEYS */;
INSERT INTO `sys_history` VALUES (1,1652457431,2,'BE',1,0,1,'be_users','{\"oldRecord\":{\"password\":\"$argon2i$v=19$m=65536,t=16,p=1$Y2hsTHBKRnNvQkJHLk0wZw$W\\/MMHXyTVt423n5X9u7U\\/LLkMnNzwfQICZOAqABvfrQ\"},\"newRecord\":{\"password\":\"$argon2i$v=19$m=65536,t=16,p=1$V2lteC9jY3k4NUc5a0ZNQw$OKdzi9uEEwpZ\\/FQtg8G5hj6V7cEWHdbTSqKmaN1PU+E\"}}',0,'0400$da087a1ecfe55f2ea12f31e47add518d:084907bc914ff27cf2301aec50eb66b2'),(2,1652457445,1,'BE',1,0,1,'pages','{\"uid\":1,\"pid\":0,\"tstamp\":1652457445,\"crdate\":1652457445,\"cruser_id\":1,\"deleted\":0,\"hidden\":1,\"starttime\":0,\"endtime\":0,\"fe_group\":\"0\",\"sorting\":256,\"rowDescription\":null,\"editlock\":0,\"sys_language_uid\":0,\"l10n_parent\":0,\"l10n_source\":0,\"l10n_state\":null,\"t3_origuid\":0,\"l10n_diffsource\":\"\",\"t3ver_oid\":0,\"t3ver_wsid\":0,\"t3ver_state\":0,\"t3ver_stage\":0,\"perms_userid\":1,\"perms_groupid\":0,\"perms_user\":31,\"perms_group\":27,\"perms_everybody\":0,\"title\":\"Home\",\"slug\":\"\\/\",\"doktype\":1,\"TSconfig\":null,\"is_siteroot\":0,\"php_tree_stop\":0,\"url\":\"\",\"shortcut\":0,\"shortcut_mode\":0,\"subtitle\":\"\",\"layout\":0,\"target\":\"\",\"media\":0,\"lastUpdated\":0,\"keywords\":null,\"cache_timeout\":0,\"cache_tags\":\"\",\"newUntil\":0,\"description\":null,\"no_search\":0,\"SYS_LASTCHANGED\":0,\"abstract\":null,\"module\":\"\",\"extendToSubpages\":0,\"author\":\"\",\"author_email\":\"\",\"nav_title\":\"\",\"nav_hide\":0,\"content_from_pid\":0,\"mount_pid\":0,\"mount_pid_ol\":0,\"l18n_cfg\":0,\"fe_login_mode\":0,\"backend_layout\":\"\",\"backend_layout_next_level\":\"\",\"tsconfig_includes\":null,\"categories\":0,\"tx_impexp_origuid\":0,\"seo_title\":\"\",\"no_index\":0,\"no_follow\":0,\"og_title\":\"\",\"og_description\":null,\"og_image\":0,\"twitter_title\":\"\",\"twitter_description\":null,\"twitter_image\":0,\"twitter_card\":\"summary\",\"canonical_link\":\"\",\"sitemap_priority\":\"0.5\",\"sitemap_changefreq\":\"\"}',0,'0400$11580a35a2286553ef84a90a45ccd7ad:e175f7045d7ccbfb26ffcf279422c2e5'),(3,1652457448,2,'BE',1,0,1,'pages','{\"oldRecord\":{\"hidden\":1,\"l10n_diffsource\":\"\"},\"newRecord\":{\"hidden\":\"0\",\"l10n_diffsource\":\"{\\\"hidden\\\":\\\"\\\"}\"}}',0,'0400$8f13b203361348b4ebbc758e035316b1:e175f7045d7ccbfb26ffcf279422c2e5'),(4,1652457490,2,'BE',1,0,1,'pages','{\"oldRecord\":{\"is_siteroot\":0,\"fe_group\":\"0\",\"l10n_diffsource\":\"{\\\"hidden\\\":\\\"\\\"}\"},\"newRecord\":{\"is_siteroot\":\"1\",\"fe_group\":\"\",\"l10n_diffsource\":\"{\\\"doktype\\\":\\\"\\\",\\\"title\\\":\\\"\\\",\\\"slug\\\":\\\"\\\",\\\"nav_title\\\":\\\"\\\",\\\"subtitle\\\":\\\"\\\",\\\"seo_title\\\":\\\"\\\",\\\"description\\\":\\\"\\\",\\\"no_index\\\":\\\"\\\",\\\"no_follow\\\":\\\"\\\",\\\"canonical_link\\\":\\\"\\\",\\\"sitemap_changefreq\\\":\\\"\\\",\\\"sitemap_priority\\\":\\\"\\\",\\\"og_title\\\":\\\"\\\",\\\"og_description\\\":\\\"\\\",\\\"og_image\\\":\\\"\\\",\\\"twitter_title\\\":\\\"\\\",\\\"twitter_description\\\":\\\"\\\",\\\"twitter_image\\\":\\\"\\\",\\\"twitter_card\\\":\\\"\\\",\\\"abstract\\\":\\\"\\\",\\\"keywords\\\":\\\"\\\",\\\"author\\\":\\\"\\\",\\\"author_email\\\":\\\"\\\",\\\"lastUpdated\\\":\\\"\\\",\\\"layout\\\":\\\"\\\",\\\"newUntil\\\":\\\"\\\",\\\"backend_layout\\\":\\\"\\\",\\\"backend_layout_next_level\\\":\\\"\\\",\\\"content_from_pid\\\":\\\"\\\",\\\"target\\\":\\\"\\\",\\\"cache_timeout\\\":\\\"\\\",\\\"cache_tags\\\":\\\"\\\",\\\"is_siteroot\\\":\\\"\\\",\\\"no_search\\\":\\\"\\\",\\\"php_tree_stop\\\":\\\"\\\",\\\"module\\\":\\\"\\\",\\\"media\\\":\\\"\\\",\\\"tsconfig_includes\\\":\\\"\\\",\\\"TSconfig\\\":\\\"\\\",\\\"l18n_cfg\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"nav_hide\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"extendToSubpages\\\":\\\"\\\",\\\"fe_group\\\":\\\"\\\",\\\"fe_login_mode\\\":\\\"\\\",\\\"editlock\\\":\\\"\\\",\\\"categories\\\":\\\"\\\",\\\"rowDescription\\\":\\\"\\\"}\"}}',0,'0400$ca3beffb04c58ef38dfd56371edc4189:e175f7045d7ccbfb26ffcf279422c2e5'),(5,1652457501,1,'BE',1,0,1,'sys_template','{\"uid\":1,\"pid\":1,\"tstamp\":1652457501,\"crdate\":1652457501,\"cruser_id\":1,\"deleted\":0,\"hidden\":0,\"starttime\":0,\"endtime\":0,\"sorting\":256,\"description\":null,\"t3_origuid\":0,\"t3ver_oid\":0,\"t3ver_wsid\":0,\"t3ver_state\":0,\"t3ver_stage\":0,\"title\":\"NEW SITE\",\"root\":1,\"clear\":3,\"include_static_file\":null,\"constants\":null,\"config\":\"\\n# Default PAGE object:\\npage = PAGE\\npage.10 = TEXT\\npage.10.value = HELLO WORLD!\\n\",\"basedOn\":\"\",\"includeStaticAfterBasedOn\":0,\"static_file_mode\":0,\"tx_impexp_origuid\":0}',0,'0400$6c85cffb9bc9d2f67456376808e545bc:35af6288617af54964e77af08c30949a'),(6,1653463479,1,'BE',1,0,2,'pages','{\"uid\":2,\"pid\":1,\"tstamp\":1653463479,\"crdate\":1653463479,\"cruser_id\":1,\"deleted\":0,\"hidden\":1,\"starttime\":0,\"endtime\":0,\"fe_group\":\"0\",\"sorting\":256,\"rowDescription\":null,\"editlock\":0,\"sys_language_uid\":0,\"l10n_parent\":0,\"l10n_source\":0,\"l10n_state\":null,\"t3_origuid\":0,\"l10n_diffsource\":\"\",\"t3ver_oid\":0,\"t3ver_wsid\":0,\"t3ver_state\":0,\"t3ver_stage\":0,\"perms_userid\":1,\"perms_groupid\":0,\"perms_user\":31,\"perms_group\":27,\"perms_everybody\":0,\"title\":\"Users\",\"slug\":\"\\/users\",\"doktype\":254,\"TSconfig\":null,\"is_siteroot\":0,\"php_tree_stop\":0,\"url\":\"\",\"shortcut\":0,\"shortcut_mode\":0,\"subtitle\":\"\",\"layout\":0,\"target\":\"\",\"media\":0,\"lastUpdated\":0,\"keywords\":null,\"cache_timeout\":0,\"cache_tags\":\"\",\"newUntil\":0,\"description\":null,\"no_search\":0,\"SYS_LASTCHANGED\":0,\"abstract\":null,\"module\":\"\",\"extendToSubpages\":0,\"author\":\"\",\"author_email\":\"\",\"nav_title\":\"\",\"nav_hide\":0,\"content_from_pid\":0,\"mount_pid\":0,\"mount_pid_ol\":0,\"l18n_cfg\":0,\"fe_login_mode\":0,\"backend_layout\":\"\",\"backend_layout_next_level\":\"\",\"tsconfig_includes\":null,\"categories\":0,\"tx_impexp_origuid\":0,\"seo_title\":\"\",\"no_index\":0,\"no_follow\":0,\"og_title\":\"\",\"og_description\":null,\"og_image\":0,\"twitter_title\":\"\",\"twitter_description\":null,\"twitter_image\":0,\"twitter_card\":\"summary\",\"canonical_link\":\"\",\"sitemap_priority\":\"0.5\",\"sitemap_changefreq\":\"\"}',0,'0400$1ef5c6ce6aaf7e9ec7f0b243a2fb4db9:f11830df10b4b0bca2db34810c2241b3'),(7,1653463483,2,'BE',1,0,2,'pages','{\"oldRecord\":{\"hidden\":1,\"l10n_diffsource\":\"\"},\"newRecord\":{\"hidden\":\"0\",\"l10n_diffsource\":\"{\\\"hidden\\\":\\\"\\\"}\"}}',0,'0400$036fb458092afd9802fc27b0eaf98a01:f11830df10b4b0bca2db34810c2241b3'),(8,1653463503,1,'BE',1,0,1,'fe_groups','{\"uid\":1,\"pid\":2,\"tstamp\":1653463503,\"crdate\":1653463503,\"cruser_id\":1,\"deleted\":0,\"hidden\":0,\"description\":\"\",\"tx_extbase_type\":\"0\",\"title\":\"customer\",\"subgroup\":\"\",\"TSconfig\":\"\",\"felogin_redirectPid\":\"\"}',0,'0400$a8f4c9419996673d6aafb1d5ed54d018:74fdbe61b0d9932f32a509c1ca766543'),(9,1653463525,1,'BE',1,0,1,'fe_users','{\"uid\":1,\"pid\":2,\"tstamp\":1653463525,\"crdate\":1653463525,\"cruser_id\":1,\"deleted\":0,\"disable\":0,\"starttime\":0,\"endtime\":0,\"description\":\"\",\"tx_extbase_type\":\"0\",\"username\":\"test\",\"password\":\"$argon2i$v=19$m=65536,t=16,p=1$NGhMWVJ4TzVwWjJ6UlV4NQ$aWg3EGm29oA+5KQ9iEqetdKsC3DK1YtQXvw\\/09yDmvM\",\"usergroup\":\"1\",\"name\":\"\",\"first_name\":\"\",\"middle_name\":\"\",\"last_name\":\"\",\"address\":\"\",\"telephone\":\"\",\"fax\":\"\",\"email\":\"\",\"uc\":null,\"title\":\"\",\"zip\":\"\",\"city\":\"\",\"country\":\"\",\"www\":\"\",\"company\":\"\",\"image\":null,\"TSconfig\":\"\",\"lastlogin\":0,\"is_online\":0,\"mfa\":null,\"felogin_redirectPid\":\"\",\"felogin_forgotHash\":\"\"}',0,'0400$c5166778575224d59b8c416f56cefb2e:237e89c1b2a56068427543279fe1982e'),(10,1653472618,2,'BE',1,0,1,'fe_users','{\"oldRecord\":{\"image\":null},\"newRecord\":{\"image\":0}}',0,'0400$a2f52283f39ab1a4e3f17e012e33f734:237e89c1b2a56068427543279fe1982e'),(11,1653473145,2,'BE',1,0,1,'fe_users','{\"oldRecord\":{\"tx_extbase_type\":\"0\"},\"newRecord\":{\"tx_extbase_type\":\"Tx_Extbase_Domain_Model_FrontendUser\"}}',0,'0400$4900c1595589cd0deb7602b5671bf76e:237e89c1b2a56068427543279fe1982e'),(12,1653473152,2,'BE',1,0,1,'fe_users','{\"oldRecord\":{\"tx_extbase_type\":\"Tx_Extbase_Domain_Model_FrontendUser\"},\"newRecord\":{\"tx_extbase_type\":\"0\"}}',0,'0400$d4167dc75455b354290d2f63c66aaa09:237e89c1b2a56068427543279fe1982e'),(13,1653492578,2,'BE',1,0,19,'fe_users','{\"oldRecord\":{\"email\":\"info@imobersteg-krantechnik.ch\",\"image\":null},\"newRecord\":{\"email\":\"\",\"image\":0}}',0,'0400$131e4682955cc73335c2a291dd9bedd4:c0dd21d56fc2fc6582672caf78f112f7'),(14,1653560204,2,'BE',1,0,19,'fe_users','{\"oldRecord\":{\"image\":null,\"tx_bexio_id\":27,\"tx_bexio_company_id\":26},\"newRecord\":{\"image\":0,\"tx_bexio_id\":\"0\",\"tx_bexio_company_id\":\"0\"}}',0,'0400$8bea78b355f14d35e293f7455033a3f7:c0dd21d56fc2fc6582672caf78f112f7'),(15,1653560340,4,'BE',1,0,26,'fe_users',NULL,0,'0400$c805b1fa2327938e5b2e716a2341e007:2080e098d417791c09144c78ed9bf4f6'),(16,1653560574,4,'BE',1,0,27,'fe_users',NULL,0,'0400$cd504aeb212367ab527dc7eed005fb8c:fd4ebf48aa69e071da1d147b7fc756a1'),(17,1653560620,2,'BE',1,0,19,'fe_users','{\"oldRecord\":{\"email\":\"info@imobersteg-krantechnik.ch\"},\"newRecord\":{\"email\":\"info2@imobersteg-krantechnik.ch\"}}',0,'0400$87a6a5512a8668ab111c645c821b6e9a:c0dd21d56fc2fc6582672caf78f112f7'),(18,1653560652,2,'BE',1,0,19,'fe_users','{\"oldRecord\":{\"email\":\"info2@imobersteg-krantechnik.ch\"},\"newRecord\":{\"email\":\"\"}}',0,'0400$f8187265bb50f776c5e023510ce96f85:c0dd21d56fc2fc6582672caf78f112f7'),(19,1653560900,2,'BE',1,0,19,'fe_users','{\"oldRecord\":{\"company\":\"Imobersteg GmbH\",\"address\":\"Schwandistrasse 12B\",\"zip\":\"3714\",\"city\":\"Frutigen\",\"country\":\"Schweiz\",\"tx_bexio_id\":27,\"tx_bexio_company_id\":26},\"newRecord\":{\"company\":\"\",\"address\":\"\",\"zip\":\"\",\"city\":\"\",\"country\":\"\",\"tx_bexio_id\":\"0\",\"tx_bexio_company_id\":\"0\"}}',0,'0400$34927046eeb1ae3dee438b0bb450ac72:c0dd21d56fc2fc6582672caf78f112f7'),(20,1653627300,2,'BE',1,0,19,'fe_users','{\"oldRecord\":{\"image\":null,\"tx_bexio_id\":27,\"tx_bexio_company_id\":26},\"newRecord\":{\"image\":0,\"tx_bexio_id\":\"0\",\"tx_bexio_company_id\":\"0\"}}',0,'0400$ef9d815e37802896283bb6882d112784:c0dd21d56fc2fc6582672caf78f112f7'),(21,1653627436,2,'BE',1,0,19,'fe_users','{\"oldRecord\":{\"company\":\"Imobersteg GmbH\"},\"newRecord\":{\"company\":\"\"}}',0,'0400$3a2f5e8a927ff3e2316b42692b981b16:c0dd21d56fc2fc6582672caf78f112f7'),(22,1653627840,2,'BE',1,0,19,'fe_users','{\"oldRecord\":{\"company\":\"Imobersteg GmbH\",\"image\":null},\"newRecord\":{\"company\":\"\",\"image\":0}}',0,'0400$bcd38ec718568b6f1f1e642575d7cd8d:c0dd21d56fc2fc6582672caf78f112f7'),(23,1653627910,2,'BE',1,0,19,'fe_users','{\"oldRecord\":{\"company\":\"Imobersteg GmbH\"},\"newRecord\":{\"company\":\"\"}}',0,'0400$2140096de5bb85977e52acee0778bc88:c0dd21d56fc2fc6582672caf78f112f7'),(24,1653627977,2,'BE',1,0,19,'fe_users','{\"oldRecord\":{\"company\":\"Imobersteg GmbH\"},\"newRecord\":{\"company\":\"Imobersteg2 GmbH\"}}',0,'0400$6e52909064d58d00d81cb88139009cfa:c0dd21d56fc2fc6582672caf78f112f7'),(25,1653633931,2,'BE',1,0,19,'fe_users','{\"oldRecord\":{\"company\":\"Imobersteg GmbH\"},\"newRecord\":{\"company\":\"Imobersteg2 GmbH\"}}',0,'0400$99ed111e7c612939400c99322d0bc8a7:c0dd21d56fc2fc6582672caf78f112f7'),(26,1653640976,2,'BE',1,0,19,'fe_users','{\"oldRecord\":{\"company\":\"Imobersteg GmbH\",\"image\":null},\"newRecord\":{\"company\":\"Imobersteg2 GmbH\",\"image\":0}}',0,'0400$45b9f00f38cccd80ea847d3a76764f16:c0dd21d56fc2fc6582672caf78f112f7'),(27,1653653907,2,'BE',1,0,26,'fe_users','{\"oldRecord\":{\"company\":\"Test GmbH\",\"image\":null},\"newRecord\":{\"company\":\"Test2 GmbH\",\"image\":0}}',0,'0400$47d5eaec8b728202f2657b17abd1fcf8:2080e098d417791c09144c78ed9bf4f6'),(28,1653653950,2,'BE',1,0,26,'fe_users','{\"oldRecord\":{\"company\":\"Test GmbH\"},\"newRecord\":{\"company\":\"\"}}',0,'0400$a97d1a7443b1a2199c8bc8e41a3e006a:2080e098d417791c09144c78ed9bf4f6'),(29,1653994493,1,'BE',1,0,3,'pages','{\"uid\":3,\"pid\":1,\"tstamp\":1653994493,\"crdate\":1653994493,\"cruser_id\":1,\"deleted\":0,\"hidden\":1,\"starttime\":0,\"endtime\":0,\"fe_group\":\"0\",\"sorting\":512,\"rowDescription\":null,\"editlock\":0,\"sys_language_uid\":0,\"l10n_parent\":0,\"l10n_source\":0,\"l10n_state\":null,\"t3_origuid\":0,\"l10n_diffsource\":\"\",\"t3ver_oid\":0,\"t3ver_wsid\":0,\"t3ver_state\":0,\"t3ver_stage\":0,\"perms_userid\":1,\"perms_groupid\":0,\"perms_user\":31,\"perms_group\":27,\"perms_everybody\":0,\"title\":\"Invoices\",\"slug\":\"\\/invoices\",\"doktype\":254,\"TSconfig\":null,\"is_siteroot\":0,\"php_tree_stop\":0,\"url\":\"\",\"shortcut\":0,\"shortcut_mode\":0,\"subtitle\":\"\",\"layout\":0,\"target\":\"\",\"media\":0,\"lastUpdated\":0,\"keywords\":null,\"cache_timeout\":0,\"cache_tags\":\"\",\"newUntil\":0,\"description\":null,\"no_search\":0,\"SYS_LASTCHANGED\":0,\"abstract\":null,\"module\":\"\",\"extendToSubpages\":0,\"author\":\"\",\"author_email\":\"\",\"nav_title\":\"\",\"nav_hide\":0,\"content_from_pid\":0,\"mount_pid\":0,\"mount_pid_ol\":0,\"l18n_cfg\":0,\"fe_login_mode\":0,\"backend_layout\":\"\",\"backend_layout_next_level\":\"\",\"tsconfig_includes\":null,\"categories\":0,\"tx_impexp_origuid\":0,\"seo_title\":\"\",\"no_index\":0,\"no_follow\":0,\"og_title\":\"\",\"og_description\":null,\"og_image\":0,\"twitter_title\":\"\",\"twitter_description\":null,\"twitter_image\":0,\"twitter_card\":\"summary\",\"canonical_link\":\"\",\"sitemap_priority\":\"0.5\",\"sitemap_changefreq\":\"\"}',0,'0400$b233034b9fc0bf1c911c73b53547d547:fe15eeb7d49e64e2cea91ab53fcf0db1'),(30,1653994498,2,'BE',1,0,3,'pages','{\"oldRecord\":{\"hidden\":1,\"l10n_diffsource\":\"\"},\"newRecord\":{\"hidden\":\"0\",\"l10n_diffsource\":\"{\\\"hidden\\\":\\\"\\\"}\"}}',0,'0400$18ba6bc9d8300793acd45ba5bf6cd5de:fe15eeb7d49e64e2cea91ab53fcf0db1'),(31,1653997128,2,'BE',1,0,19,'fe_users','{\"oldRecord\":{\"image\":null},\"newRecord\":{\"image\":0}}',0,'0400$1432d2e8e2abc53c40eeaeef64836256:c0dd21d56fc2fc6582672caf78f112f7'),(32,1654072939,2,'BE',1,0,26,'fe_users','{\"oldRecord\":{\"image\":null,\"tx_bexio_id\":43,\"tx_bexio_company_id\":42},\"newRecord\":{\"image\":0,\"tx_bexio_id\":\"0\",\"tx_bexio_company_id\":\"0\"}}',0,'0400$57f60b9f8d0707736ee45df06a6ac415:2080e098d417791c09144c78ed9bf4f6'),(33,1654072971,2,'BE',1,0,26,'fe_users','{\"oldRecord\":{\"company\":\"Test GmbH\"},\"newRecord\":{\"company\":\"Test GmbH2\"}}',0,'0400$181072e5f09305be037443a57d7c9bbd:2080e098d417791c09144c78ed9bf4f6'),(34,1654177989,2,'BE',1,0,26,'fe_users','{\"oldRecord\":{\"company\":\"Test GmbH\",\"image\":null},\"newRecord\":{\"company\":\"Test GmbH2\",\"image\":0}}',0,'0400$7627c17231ae54e578ee276f1c68c3b7:2080e098d417791c09144c78ed9bf4f6'),(35,1654263765,2,'BE',1,0,1,'tx_bexio_domain_model_invoice','{\"oldRecord\":{\"user\":7},\"newRecord\":{\"user\":1}}',0,'0400$c226d3e400c4146e69cb173276f6d0bc:f086744559a6ca6483d5fdb8edefb103'),(36,1654320251,2,'BE',1,0,1,'fe_users','{\"oldRecord\":{\"image\":null},\"newRecord\":{\"image\":0}}',0,'0400$924e491ec2738c4206ee29e906e22398:237e89c1b2a56068427543279fe1982e'),(37,1654320251,2,'BE',1,0,1,'tx_bexio_domain_model_invoice','{\"oldRecord\":{\"user\":7},\"newRecord\":{\"user\":1}}',0,'0400$924e491ec2738c4206ee29e906e22398:f086744559a6ca6483d5fdb8edefb103'),(38,1654325725,2,'BE',1,0,7,'fe_users','{\"oldRecord\":{\"image\":null,\"tx_bexio_invoices\":0},\"newRecord\":{\"image\":0,\"tx_bexio_invoices\":15}}',0,'0400$5c254a2763431dfd078bd10fc2a5b3d6:784e809088604e8dc62bc02e28f55236'),(39,1654574276,2,'BE',1,0,52,'fe_users','{\"oldRecord\":{\"password\":\"sali!\",\"company\":\"Test GmbH\",\"image\":null},\"newRecord\":{\"password\":\"$argon2i$v=19$m=65536,t=16,p=1$cWh0NXNtM2pEQkNpc01NMw$KkrhxkC2PmtWQM39gAeWexvAkiQ5mZzJW+1eTuxORSs\",\"company\":\"Test GmbH2\",\"image\":0}}',0,'0400$1d1a59b9bd508e16e98a30372beb4901:f071968325bea997b1e1b9c0292becca'),(40,1654574774,2,'BE',1,0,52,'fe_users','{\"oldRecord\":{\"company\":\"Test GmbH\"},\"newRecord\":{\"company\":\"Test GmbH2\"}}',0,'0400$7f6b1c1b89c888511e0a2d9d5b5fa4bc:f071968325bea997b1e1b9c0292becca'),(41,1654574810,2,'BE',1,0,52,'fe_users','{\"oldRecord\":{\"company\":\"Test GmbH\"},\"newRecord\":{\"company\":\"Test GmbH2\"}}',0,'0400$e3da8d3840afe4366e26771d6333ae3d:f071968325bea997b1e1b9c0292becca'),(42,1654574865,2,'BE',1,0,52,'fe_users','{\"oldRecord\":{\"company\":\"Test GmbH\"},\"newRecord\":{\"company\":\"\"}}',0,'0400$2c0cc33a70d632e6f9b1d4fd4e2345d0:f071968325bea997b1e1b9c0292becca'),(43,1654576499,2,'BE',1,0,52,'fe_users','{\"oldRecord\":{\"tx_bexio_id\":43,\"tx_bexio_company_id\":42},\"newRecord\":{\"tx_bexio_id\":\"0\",\"tx_bexio_company_id\":\"0\"}}',0,'0400$b14feabc55ee0a69617de1ba945bb83b:f071968325bea997b1e1b9c0292becca'),(44,1654579003,2,'BE',1,0,52,'fe_users','{\"oldRecord\":{\"tx_bexio_id\":43,\"tx_bexio_company_id\":42},\"newRecord\":{\"tx_bexio_id\":\"0\",\"tx_bexio_company_id\":\"0\"}}',0,'0400$d33c5d0bfa732e45419a5779d5414622:f071968325bea997b1e1b9c0292becca'),(45,1654585026,2,'BE',1,0,26,'fe_users','{\"oldRecord\":{\"password\":\"znB@T17vS2oshflKk4ub\",\"company\":\"Test GmbH\",\"image\":null,\"tx_bexio_invoices\":0},\"newRecord\":{\"password\":\"$argon2i$v=19$m=65536,t=16,p=1$RzF4YkptVUlPLm1YTEZYNQ$pEQXhnUxmc+7VGUAbAd\\/SGeZjdDOngBsoUgTUkjFea8\",\"company\":\"\",\"image\":0,\"tx_bexio_invoices\":4}}',0,'0400$eea98f3536e8b9d606184cb4a9db5251:2080e098d417791c09144c78ed9bf4f6'),(46,1654585048,2,'BE',1,0,26,'fe_users','{\"oldRecord\":{\"company\":\"Test GmbH\"},\"newRecord\":{\"company\":\"Test GmbH2\"}}',0,'0400$9bde528a8302036f7f72383180466efb:2080e098d417791c09144c78ed9bf4f6'),(47,1654585083,2,'BE',1,0,26,'fe_users','{\"oldRecord\":{\"tx_bexio_id\":43,\"tx_bexio_company_id\":42},\"newRecord\":{\"tx_bexio_id\":\"0\",\"tx_bexio_company_id\":\"0\"}}',0,'0400$2d65476c48181886d74f67193530f8e9:2080e098d417791c09144c78ed9bf4f6');
/*!40000 ALTER TABLE `sys_history` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_language`
--

DROP TABLE IF EXISTS `sys_language`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_language` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `sorting` int(11) NOT NULL DEFAULT 0,
  `title` varchar(80) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `flag` varchar(20) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `language_isocode` varchar(2) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`hidden`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_language`
--

LOCK TABLES `sys_language` WRITE;
/*!40000 ALTER TABLE `sys_language` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_language` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_lockedrecords`
--

DROP TABLE IF EXISTS `sys_lockedrecords`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_lockedrecords` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `userid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `record_table` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `record_uid` int(11) NOT NULL DEFAULT 0,
  `record_pid` int(11) NOT NULL DEFAULT 0,
  `username` varchar(50) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `feuserid` int(10) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `event` (`userid`,`tstamp`)
) ENGINE=InnoDB AUTO_INCREMENT=147 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_lockedrecords`
--

LOCK TABLES `sys_lockedrecords` WRITE;
/*!40000 ALTER TABLE `sys_lockedrecords` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_lockedrecords` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_news`
--

DROP TABLE IF EXISTS `sys_news`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_news` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `cruser_id` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `title` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `content` mediumtext COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`,`hidden`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_news`
--

LOCK TABLES `sys_news` WRITE;
/*!40000 ALTER TABLE `sys_news` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_news` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_note`
--

DROP TABLE IF EXISTS `sys_note`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_note` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `cruser` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `sorting` int(11) NOT NULL DEFAULT 0,
  `subject` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `message` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `personal` smallint(5) unsigned NOT NULL DEFAULT 0,
  `category` smallint(5) unsigned NOT NULL DEFAULT 0,
  `position` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_note`
--

LOCK TABLES `sys_note` WRITE;
/*!40000 ALTER TABLE `sys_note` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_note` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_refindex`
--

DROP TABLE IF EXISTS `sys_refindex`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_refindex` (
  `hash` varchar(32) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `tablename` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `recuid` int(11) NOT NULL DEFAULT 0,
  `field` varchar(64) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `flexpointer` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `softref_key` varchar(30) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `softref_id` varchar(40) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `sorting` int(11) NOT NULL DEFAULT 0,
  `workspace` int(11) NOT NULL DEFAULT 0,
  `ref_table` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `ref_uid` int(11) NOT NULL DEFAULT 0,
  `ref_string` varchar(1024) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`hash`),
  KEY `lookup_rec` (`tablename`(100),`recuid`),
  KEY `lookup_uid` (`ref_table`(100),`ref_uid`),
  KEY `lookup_string` (`ref_string`(191))
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_refindex`
--

LOCK TABLES `sys_refindex` WRITE;
/*!40000 ALTER TABLE `sys_refindex` DISABLE KEYS */;
INSERT INTO `sys_refindex` VALUES ('001cd2e4390e0152274a1a31cabbf067','fe_users',1,'usergroup','','','',0,0,'fe_groups',1,''),('0a7f63b832e92311659c718b1d5750df','fe_users',1,'tx_bexio_invoices','','','',0,0,'tx_bexio_domain_model_invoice',1,''),('0c2468fb90afc7b527e1573bcd638e5b','fe_users',7,'tx_bexio_invoices','','','',10,0,'tx_bexio_domain_model_invoice',5,''),('11316ab991bf1f260934365b9cb55153','fe_users',52,'usergroup','','','',0,0,'fe_groups',1,''),('11b528e01a8a964710efe065177790a1','tx_bexio_domain_model_invoice',21,'user','','','',0,0,'fe_users',26,''),('130f3bd953747abe7eaed19974211628','fe_users',7,'tx_bexio_invoices','','','',12,0,'tx_bexio_domain_model_invoice',3,''),('13b9eef3307161de0d9e8fc8627c7bad','fe_users',7,'usergroup','','','',0,0,'fe_groups',1,''),('142022fd0e5392b3516dbfab143b675a','fe_users',7,'tx_bexio_invoices','','','',4,0,'tx_bexio_domain_model_invoice',14,''),('162d2f6a5906f86434eca3e8f944046c','fe_users',7,'tx_bexio_invoices','','','',5,0,'tx_bexio_domain_model_invoice',13,''),('1881c2ae125b24be6c3d17e691b41ba5','fe_users',26,'tx_bexio_invoices','','','',3,0,'tx_bexio_domain_model_invoice',21,''),('1ca53b46a909b637174c35d82d6c553d','fe_users',26,'tx_bexio_invoices','','','',1,0,'tx_bexio_domain_model_invoice',22,''),('2778663aa42fda244b698bf81847efdf','fe_users',7,'tx_bexio_invoices','','','',2,0,'tx_bexio_domain_model_invoice',16,''),('33412985957431de17dc721fc52cf142','fe_users',7,'tx_bexio_invoices','','','',6,0,'tx_bexio_domain_model_invoice',11,''),('4d855f2979cfa86cc600a38f5d4625a2','tx_bexio_domain_model_invoice',19,'user','','','',0,0,'fe_users',26,''),('5d21ddbdb7066a86fa6d4334e70e9f95','fe_users',7,'tx_bexio_invoices','','','',8,0,'tx_bexio_domain_model_invoice',7,''),('5f17b795d0c46364f5e8a610b791ba00','fe_users',7,'tx_bexio_invoices','','','',7,0,'tx_bexio_domain_model_invoice',9,''),('64099b20760b8f70f2b733497ee8daab','fe_users',19,'usergroup','','','',0,0,'fe_groups',1,''),('70c69ab63ca9264b9649dcdefea6789c','fe_users',7,'tx_bexio_invoices','','','',11,0,'tx_bexio_domain_model_invoice',4,''),('741969d6d62cc2ac3835d91f19e29084','fe_users',26,'tx_bexio_invoices','','','',0,0,'tx_bexio_domain_model_invoice',20,''),('8104b59f99efb8a1bfb4e05a418d97e7','fe_users',7,'tx_bexio_invoices','','','',1,0,'tx_bexio_domain_model_invoice',17,''),('91ce8065cac838a54e4b6d4e652c8e5b','tx_bexio_domain_model_invoice',15,'user','','','',0,0,'fe_users',7,''),('92b1c7922e4b8366dd7add4ac5b2925a','fe_users',26,'usergroup','','','',0,0,'fe_groups',1,''),('999ce8dc910d32ea89e2a0a3537cccca','fe_users',7,'tx_bexio_invoices','','','',9,0,'tx_bexio_domain_model_invoice',6,''),('9c370faf5bd32cd189a567d8fb5f15c5','tx_bexio_domain_model_invoice',20,'user','','','',0,0,'fe_users',26,''),('a283f0bb6b4418a3bae604b1c2afa40d','fe_users',26,'tx_bexio_invoices','','','',2,0,'tx_bexio_domain_model_invoice',19,''),('a3f3c7d72547871dd071235b7f56a787','fe_users',7,'tx_bexio_invoices','','','',14,0,'tx_bexio_domain_model_invoice',1,''),('aa855e931320c594595cced35c227876','tx_bexio_domain_model_invoice',22,'user','','','',0,0,'fe_users',26,''),('c33f6ce8339b1a9e9cefd0d74aba171a','fe_users',7,'tx_bexio_invoices','','','',13,0,'tx_bexio_domain_model_invoice',2,''),('c8e2261d7ea177dc9f0a3596be458175','fe_users',7,'tx_bexio_invoices','','','',0,0,'tx_bexio_domain_model_invoice',18,''),('e361658135ce61e1a43b74acf71a44a5','fe_users',7,'tx_bexio_invoices','','','',3,0,'tx_bexio_domain_model_invoice',15,'');
/*!40000 ALTER TABLE `sys_refindex` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_registry`
--

DROP TABLE IF EXISTS `sys_registry`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_registry` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `entry_namespace` varchar(128) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `entry_key` varchar(128) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `entry_value` mediumblob DEFAULT NULL,
  PRIMARY KEY (`uid`),
  UNIQUE KEY `entry_identifier` (`entry_namespace`,`entry_key`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_registry`
--

LOCK TABLES `sys_registry` WRITE;
/*!40000 ALTER TABLE `sys_registry` DISABLE KEYS */;
INSERT INTO `sys_registry` VALUES (1,'installUpdate','TYPO3\\CMS\\Install\\Updates\\FeeditExtractionUpdate','i:1;'),(2,'installUpdate','TYPO3\\CMS\\Install\\Updates\\TaskcenterExtractionUpdate','i:1;'),(3,'installUpdate','TYPO3\\CMS\\Install\\Updates\\SysActionExtractionUpdate','i:1;'),(4,'installUpdate','TYPO3\\CMS\\Install\\Updates\\SvgFilesSanitization','i:1;'),(5,'installUpdate','TYPO3\\CMS\\Install\\Updates\\ShortcutRecordsMigration','i:1;'),(6,'installUpdate','TYPO3\\CMS\\Install\\Updates\\CollectionsExtractionUpdate','i:1;'),(7,'installUpdate','TYPO3\\CMS\\Install\\Updates\\BackendUserLanguageMigration','i:1;'),(8,'installUpdate','TYPO3\\CMS\\Install\\Updates\\SysLogChannel','i:1;'),(9,'installUpdate','TYPO3\\CMS\\FrontendLogin\\Updates\\MigrateFeloginPlugins','i:1;'),(10,'installUpdateRows','rowUpdatersDone','a:4:{i:0;s:69:\"TYPO3\\CMS\\Install\\Updates\\RowUpdater\\WorkspaceVersionRecordsMigration\";i:1;s:66:\"TYPO3\\CMS\\Install\\Updates\\RowUpdater\\L18nDiffsourceToJsonMigration\";i:2;s:77:\"TYPO3\\CMS\\Install\\Updates\\RowUpdater\\WorkspaceMovePlaceholderRemovalMigration\";i:3;s:76:\"TYPO3\\CMS\\Install\\Updates\\RowUpdater\\WorkspaceNewPlaceholderRemovalMigration\";}'),(11,'core','formProtectionSessionToken:1','s:64:\"9319f44aff0b241f2a79dbcb8ebfb8cf69b397181b7a9c283c31be56f682588f\";');
/*!40000 ALTER TABLE `sys_registry` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_template`
--

DROP TABLE IF EXISTS `sys_template`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_template` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(11) NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `cruser_id` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `sorting` int(11) NOT NULL DEFAULT 0,
  `description` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `t3_origuid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_oid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_wsid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_state` smallint(6) NOT NULL DEFAULT 0,
  `t3ver_stage` int(11) NOT NULL DEFAULT 0,
  `title` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `root` smallint(5) unsigned NOT NULL DEFAULT 0,
  `clear` smallint(5) unsigned NOT NULL DEFAULT 0,
  `include_static_file` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `constants` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `config` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `basedOn` tinytext COLLATE utf8_unicode_ci DEFAULT NULL,
  `includeStaticAfterBasedOn` smallint(5) unsigned NOT NULL DEFAULT 0,
  `static_file_mode` smallint(5) unsigned NOT NULL DEFAULT 0,
  `tx_impexp_origuid` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `roottemplate` (`deleted`,`hidden`,`root`),
  KEY `parent` (`pid`,`deleted`,`hidden`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_template`
--

LOCK TABLES `sys_template` WRITE;
/*!40000 ALTER TABLE `sys_template` DISABLE KEYS */;
INSERT INTO `sys_template` VALUES (1,1,1652457501,1652457501,1,0,0,0,0,256,NULL,0,0,0,0,0,'NEW SITE',1,3,NULL,NULL,'\n# Default PAGE object:\npage = PAGE\npage.10 = TEXT\npage.10.value = HELLO WORLD!\n','',0,0,0);
/*!40000 ALTER TABLE `sys_template` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tt_content`
--

DROP TABLE IF EXISTS `tt_content`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tt_content` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `rowDescription` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `pid` int(11) NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `cruser_id` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `fe_group` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  `sorting` int(11) NOT NULL DEFAULT 0,
  `editlock` smallint(5) unsigned NOT NULL DEFAULT 0,
  `sys_language_uid` int(11) NOT NULL DEFAULT 0,
  `l18n_parent` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_source` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_state` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `t3_origuid` int(10) unsigned NOT NULL DEFAULT 0,
  `l18n_diffsource` mediumblob DEFAULT NULL,
  `t3ver_oid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_wsid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_state` smallint(6) NOT NULL DEFAULT 0,
  `t3ver_stage` int(11) NOT NULL DEFAULT 0,
  `CType` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `header` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `header_position` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `bodytext` mediumtext COLLATE utf8_unicode_ci DEFAULT NULL,
  `bullets_type` smallint(5) unsigned NOT NULL DEFAULT 0,
  `uploads_description` smallint(5) unsigned NOT NULL DEFAULT 0,
  `uploads_type` smallint(5) unsigned NOT NULL DEFAULT 0,
  `assets` int(10) unsigned NOT NULL DEFAULT 0,
  `image` int(10) unsigned NOT NULL DEFAULT 0,
  `imagewidth` int(10) unsigned NOT NULL DEFAULT 0,
  `imageorient` smallint(5) unsigned NOT NULL DEFAULT 0,
  `imagecols` smallint(5) unsigned NOT NULL DEFAULT 0,
  `imageborder` smallint(5) unsigned NOT NULL DEFAULT 0,
  `media` int(10) unsigned NOT NULL DEFAULT 0,
  `layout` int(10) unsigned NOT NULL DEFAULT 0,
  `frame_class` varchar(60) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'default',
  `cols` int(10) unsigned NOT NULL DEFAULT 0,
  `space_before_class` varchar(60) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `space_after_class` varchar(60) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `records` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `pages` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `colPos` int(10) unsigned NOT NULL DEFAULT 0,
  `subheader` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `header_link` varchar(1024) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `image_zoom` smallint(5) unsigned NOT NULL DEFAULT 0,
  `header_layout` varchar(30) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  `list_type` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `sectionIndex` smallint(5) unsigned NOT NULL DEFAULT 0,
  `linkToTop` smallint(5) unsigned NOT NULL DEFAULT 0,
  `file_collections` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `filelink_size` smallint(5) unsigned NOT NULL DEFAULT 0,
  `filelink_sorting` varchar(64) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `filelink_sorting_direction` varchar(4) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `target` varchar(30) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `date` int(10) unsigned NOT NULL DEFAULT 0,
  `recursive` smallint(5) unsigned NOT NULL DEFAULT 0,
  `imageheight` int(10) unsigned NOT NULL DEFAULT 0,
  `pi_flexform` mediumtext COLLATE utf8_unicode_ci DEFAULT NULL,
  `accessibility_title` varchar(30) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `accessibility_bypass` smallint(5) unsigned NOT NULL DEFAULT 0,
  `accessibility_bypass_text` varchar(30) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `category_field` varchar(64) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `table_class` varchar(60) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `table_caption` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `table_delimiter` smallint(5) unsigned NOT NULL DEFAULT 0,
  `table_enclosure` smallint(5) unsigned NOT NULL DEFAULT 0,
  `table_header_position` smallint(5) unsigned NOT NULL DEFAULT 0,
  `table_tfoot` smallint(5) unsigned NOT NULL DEFAULT 0,
  `categories` int(10) unsigned NOT NULL DEFAULT 0,
  `selected_categories` longtext COLLATE utf8_unicode_ci DEFAULT NULL,
  `tx_impexp_origuid` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`sorting`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`),
  KEY `language` (`l18n_parent`,`sys_language_uid`),
  KEY `translation_source` (`l10n_source`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tt_content`
--

LOCK TABLES `tt_content` WRITE;
/*!40000 ALTER TABLE `tt_content` DISABLE KEYS */;
/*!40000 ALTER TABLE `tt_content` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tx_bexio_domain_model_invoice`
--

DROP TABLE IF EXISTS `tx_bexio_domain_model_invoice`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tx_bexio_domain_model_invoice` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `cruser_id` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `id` int(10) unsigned NOT NULL DEFAULT 0,
  `user` int(10) unsigned NOT NULL DEFAULT 0,
  `title` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `document_nr` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `language_id` int(10) unsigned NOT NULL DEFAULT 0,
  `bank_account_id` int(10) unsigned NOT NULL DEFAULT 0,
  `currency_id` int(10) unsigned NOT NULL DEFAULT 0,
  `total` double NOT NULL DEFAULT 0,
  `is_valid_from` int(11) NOT NULL DEFAULT 0,
  `is_valid_to` int(11) NOT NULL DEFAULT 0,
  `kb_item_status_id` int(10) unsigned NOT NULL DEFAULT 0,
  `reference` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `api_reference` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `viewed_by_client_at` int(11) NOT NULL DEFAULT 0,
  `esr_id` int(10) unsigned NOT NULL DEFAULT 0,
  `qr_invoice_id` int(10) unsigned NOT NULL DEFAULT 0,
  `network_link` varchar(511) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `payment_process_time` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`)
) ENGINE=InnoDB AUTO_INCREMENT=31 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tx_bexio_domain_model_invoice`
--

LOCK TABLES `tx_bexio_domain_model_invoice` WRITE;
/*!40000 ALTER TABLE `tx_bexio_domain_model_invoice` DISABLE KEYS */;
INSERT INTO `tx_bexio_domain_model_invoice` VALUES (1,3,1654604533,1654604533,0,0,119,7,'atemtherapie-interlaken.ch','RE-00119',1,1,1,945,1647648000,1650239999,8,'VO2lpm2P','',0,117,117,'https://network.bexio.com/invoice/02c0585e4a63139005dbe55105d46e4870041994081018a31d45355647210603',0),(2,3,1654604533,1654604533,0,0,120,7,'eheundfamilienberatung-bern.ch','RE-00120',1,1,1,326.2,1647648000,1650239999,8,'4GYdzbge','',0,118,118,'https://network.bexio.com/invoice/ef79cc03ffadbba1f5c88f39db0075ddc0b270fb4eee8d73e3fbf7cac367c810',0),(3,3,1654604533,1654604533,0,0,121,7,'ledermannbern.ch','RE-00121',1,1,1,1960,1647648000,1650239999,8,'Qy2AqG2N','',0,119,119,'https://network.bexio.com/invoice/82deb675d2dc986ad1bb70f7a373cae15cec6e612bc1d428c13c9045ae960239',0),(4,3,1654604533,1654604533,0,0,122,7,'Vorprojekte','RE-00122',1,1,1,401.1,1647648000,1650239999,8,'4La9qLaR','',0,120,120,'https://network.bexio.com/invoice/a3d17ca490f8f17b09ee6cf3a4ba395e88755aadccfeef58857fc1adbb3f7037',0),(5,3,1654604533,1654604533,0,0,123,7,'schweizer-huetten.ch','RE-00123',1,1,1,128.1,1647648000,1650239999,8,'PG2pG7gj','',0,121,121,'https://network.bexio.com/invoice/62e614cfd2f0ab886242b8b698a45ad149e6cba8fbf85c880308c17ffafeea63',0),(6,3,1654604533,1654604533,0,0,124,7,'schoenthal-ag.ch','RE-00124',1,1,1,154,1647648000,1650239999,8,'rPYVVMYl','',0,122,122,'https://network.bexio.com/invoice/d047bb94cb48dbe8368e115b206f94d506d4f8dc4a0bd1c0b67e506e701afaa2',0),(7,3,1654604533,1654604533,0,0,125,7,'vhsn.ch','RE-00125',1,1,1,205.8,1647648000,1650239999,8,'d7YZ8gWj','',0,123,123,'https://network.bexio.com/invoice/61ea8e0a86bccc1fc4d48513b83adbc7f651c3ff0d8b533fbc024145de129b67',0),(8,3,1654604533,1654604533,0,0,126,23,'sac-uto.ch','RE-00126',1,1,1,1291.5,1647648000,1650239999,8,'','',0,124,124,'https://network.bexio.com/invoice/707031088f88a6a29dbc1bc16f2be0129cc337a0aec48366b803da8ef6f47f32',0),(9,3,1654604533,1654604533,0,0,127,7,'Verschiedenes','RE-00127',1,1,1,207.2,1647648000,1650239999,8,'','',0,125,125,'https://network.bexio.com/invoice/77c950b97fbd82e6f9311aa56fd650392bbb2baa401e12c322ad57ee83dc0550',0),(10,3,1654604533,1654604533,0,0,128,12,' krebshotel.ch','RE-00128',1,1,1,67.5,1647648000,1650239999,8,'l72wvgqw','',0,126,126,'https://network.bexio.com/invoice/719dcd1f418099a8252bedd8f1e5d6a94e5d18daa590657a9f3b77abc53744c2',0),(11,3,1654604533,1654604533,0,0,129,7,'la-sia-impulse.ch','RE-00129',1,1,1,51.1,1647648000,1650239999,8,'LV2PvWaO','',0,127,127,'https://network.bexio.com/invoice/3f4a8e6ab0e562226995a0832f7786037f54cf33acae105b0dd39536b3af1258',0),(12,3,1654604533,1654604533,0,0,130,5,'villa-gaby-dugi-otok.com - TYPO3 Hilfestellung','RE-00130',1,8,2,496.22,1652486400,1655078399,8,'DOY7lvaJ','',0,128,128,'https://network.bexio.com/invoice/cd91837f80d836931aab50bea2caba890c60fc86e73df7308fb14d2bf4c9891b',0),(13,3,1654604533,1654604533,0,0,131,7,'geolab.ch - Suchmaschinenoptimierung','RE-00131',1,1,1,594.3,1652486400,1655078399,8,'4GYdbgeL','',0,129,129,'https://network.bexio.com/invoice/59fdb0f0877d5915c349cc6462a52f7c7e973c93f492a17662db1ec4b9427974',0),(14,3,1654604533,1654604533,0,0,132,7,'bircherplatten.ch','RE-00132',1,1,1,2324,1652486400,1655078399,8,'l72w3v2q','',0,130,130,'https://network.bexio.com/invoice/38f6a540952f7c03e7a2529e262b6851963c473b4a8b97e1473e9aeb1ce87b41',0),(15,3,1654604533,1654604533,0,0,133,7,'samariter-thun.ch','RE-00133',1,1,1,226.8,1652486400,1655078399,8,'4vYNjwYZ','',0,131,131,'https://network.bexio.com/invoice/94559ed07e32a5dd54ce2117e104622ea23cb1dcebce9d6cc1dd465ad955cef0',0),(16,3,1654604533,1654604533,0,0,134,7,'kiental-sesselbahnen.ch','RE-00134',1,1,1,166.6,1652486400,1655078399,8,'b0YOJE2q','',0,132,132,'https://network.bexio.com/invoice/e13f972108f39fe4f530060c0cfeb5c163d62d4e890160241d604f61ef308528',0),(17,3,1654604533,1654604533,0,0,135,7,'memoweb.ch','RE-00135',1,1,1,153.3,1652486400,1655078399,8,'DOY7v2JN','',0,133,133,'https://network.bexio.com/invoice/bd09c3b339631f3bc2948d1baa65731f41e8fc8681e691d75d75b486f9d7746a',0),(18,3,1654604533,1654604533,0,0,136,7,'notariatgermann.ch','RE-00136',1,1,1,1345.4,1652486400,1655078399,8,'4026Ve2v','',0,134,134,'https://network.bexio.com/invoice/fc9a5d76acd22069500a38e2c11585825ce507ce7b0c7a63833a1e6684398545',0),(19,3,1654604533,1654604533,0,0,147,26,'cmd inv','RE-00147',1,8,2,90,1654128000,1656719999,8,'','',0,138,138,'https://network.bexio.com/invoice/3d38328210b7f3ab1882a52158f0eeb996de93358613a24c46bda90d58f2f97c',0),(20,3,1654604533,1654604533,0,0,148,26,'cmd inv test','RE-00148',1,8,2,90,1654128000,1656719999,8,'','',0,139,139,'',0),(21,3,1654704820,1654604533,0,0,109,3,'TYPO3 Dienstleistungen','RE-00109',1,8,2,982.88,1641254400,1643846399,9,'P0OJOepFLN','',0,107,107,'https://network.bexio.com/invoice/453f36c60a1e7b2028f7f08983e32886dd3dab79a8204a298ef4a4057e5e4b00',1654704820),(22,3,1654704820,1654604533,0,0,110,7,'TYPO3 Dienstleistungen','RE-00110',1,1,1,237.3,1641340800,1643932799,9,'PG2p7gj1','',0,108,108,'https://network.bexio.com/invoice/39243e1eb7be12444f8c263a2423283ce5b81aaab84df191d1c0209c68ac43cd',1654704820),(23,3,1654704820,1654604533,0,0,111,7,'schoenthal-ag.ch','RE-00111',1,1,1,1820,1641340800,1643932799,9,'rPYVVMYl','',0,109,109,'https://network.bexio.com/invoice/7ae326b86ce879a2268623854cbbcc06e2b61c4c8e35bed2768eaa2cb555012c',1654704820),(24,3,1654704820,1654604533,0,0,112,7,'vhsn.ch','RE-00112',1,1,1,144.2,1641340800,1643932799,9,'d7YZ8gWj','',0,110,110,'https://network.bexio.com/invoice/6fe57b39584621ac565274b5dafee31896c2062ea7850057976549f8f09399bd',1654704820),(25,3,1654704820,1654604533,0,0,113,7,'geolab.ch','RE-00113',1,1,1,715.4,1641340800,1643932799,9,'2rqGay8IqA','',0,111,111,'https://network.bexio.com/invoice/27f82ffd4a6a87095fe7d04bba7f0d009d627464e79602b2757bfded61e43bf8',1654704820),(26,3,1654704820,1654604533,0,0,114,7,'notariatgermann.ch','RE-00114',1,1,1,1311.1,1641340800,1643932799,9,'ONgewvrcAb','',0,112,112,'https://network.bexio.com/invoice/b3fd7199bfd487800d57d3a5cea287c3e31ea7962d5f6154c9f2b188614f9880',1654704820),(27,3,1654704820,1654604533,0,0,115,7,'prosimmental.ch','RE-00115',1,1,1,57.4,1641340800,1643932799,9,'lJpknqAieo','',0,113,113,'https://network.bexio.com/invoice/a8b95d3f14d25c2b2cdc8447fce91ef055a290555e004c970bf64512e9ef5eb8',1654704820),(28,3,1654704820,1654604533,0,0,116,23,'Benutzerauthentifizierung via SAC-ZV','RE-00116',1,1,1,4356,1643068800,1645660799,9,'ZDOd8RjfWN','',0,114,114,'https://network.bexio.com/invoice/95e781f7f06def9dd8c6f5268a8ebe9913fe71d21af72b2d041504a3cd94374e',1654704820),(29,3,1654704820,1654604533,0,0,117,23,'Gruppeneventmanager, SAC-ZV-Authentifizierung, Messenger','RE-00117',1,1,1,5512.5,1645401600,1647993599,9,'vegJvxgR / GKar1ZYy / vL2eMK2A','',0,115,115,'https://network.bexio.com/invoice/b3e382d98970616868939944ca735b97c14dcebf571bea8c32a111245f3f1ee2',1654704820),(30,3,1654704820,1654604533,0,0,118,5,' villa-gaby-dugi-otok.com - TYPO3 Hilfestellung','RE-00118',1,8,2,130.5,1647475200,1650067199,9,'DOY7lvaJ','',0,116,116,'https://network.bexio.com/invoice/7828e29465aa3275b2f830a4a6b2918f9598a07cf058529172916b5a87850d00',1654704820);
/*!40000 ALTER TABLE `tx_bexio_domain_model_invoice` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tx_extensionmanager_domain_model_extension`
--

DROP TABLE IF EXISTS `tx_extensionmanager_domain_model_extension`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tx_extensionmanager_domain_model_extension` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `extension_key` varchar(60) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `repository` int(11) NOT NULL DEFAULT 1,
  `remote` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'ter',
  `version` varchar(15) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `alldownloadcounter` int(10) unsigned NOT NULL DEFAULT 0,
  `downloadcounter` int(10) unsigned NOT NULL DEFAULT 0,
  `title` varchar(150) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `description` mediumtext COLLATE utf8_unicode_ci DEFAULT NULL,
  `state` int(11) NOT NULL DEFAULT 0,
  `review_state` int(11) NOT NULL DEFAULT 0,
  `category` int(11) NOT NULL DEFAULT 0,
  `last_updated` int(10) unsigned NOT NULL DEFAULT 0,
  `serialized_dependencies` mediumtext COLLATE utf8_unicode_ci DEFAULT NULL,
  `author_name` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `author_email` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `ownerusername` varchar(50) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `md5hash` varchar(35) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `update_comment` mediumtext COLLATE utf8_unicode_ci DEFAULT NULL,
  `authorcompany` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `integer_version` int(11) NOT NULL DEFAULT 0,
  `current_version` int(11) NOT NULL DEFAULT 0,
  `lastreviewedversion` int(11) NOT NULL DEFAULT 0,
  `documentation_link` varchar(2048) COLLATE utf8_unicode_ci DEFAULT NULL,
  `distribution_image` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `distribution_welcome_image` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`uid`),
  UNIQUE KEY `versionextrepo` (`extension_key`,`version`,`remote`),
  KEY `index_extrepo` (`extension_key`,`remote`),
  KEY `index_versionrepo` (`integer_version`,`remote`,`extension_key`),
  KEY `index_currentversions` (`current_version`,`review_state`),
  KEY `parent` (`pid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tx_extensionmanager_domain_model_extension`
--

LOCK TABLES `tx_extensionmanager_domain_model_extension` WRITE;
/*!40000 ALTER TABLE `tx_extensionmanager_domain_model_extension` DISABLE KEYS */;
/*!40000 ALTER TABLE `tx_extensionmanager_domain_model_extension` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tx_impexp_presets`
--

DROP TABLE IF EXISTS `tx_impexp_presets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tx_impexp_presets` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `user_uid` int(10) unsigned NOT NULL DEFAULT 0,
  `title` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `public` smallint(6) NOT NULL DEFAULT 0,
  `item_uid` int(11) NOT NULL DEFAULT 0,
  `preset_data` blob DEFAULT NULL,
  PRIMARY KEY (`uid`),
  KEY `lookup` (`item_uid`),
  KEY `parent` (`pid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tx_impexp_presets`
--

LOCK TABLES `tx_impexp_presets` WRITE;
/*!40000 ALTER TABLE `tx_impexp_presets` DISABLE KEYS */;
/*!40000 ALTER TABLE `tx_impexp_presets` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-07-29 11:02:57
